import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { ProviderInput } from '../transport/api-clients';
import { _resetForTests, getDb } from '../storage/sqlite';
import {
  createOpcConversation,
  deleteOpcConversation,
  getOpcConversation,
  listOpcMessages,
} from '../storage/opc-chat';
import { runOpcChatTurn } from '../services/opc-chat';
import { companyOwnsKnowledgePack, linkKnowledgePack } from '../storage/opc-knowledge';

const originalCwd = process.cwd();
let dir = '';

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'sf-opc-chat-'));
  process.chdir(dir);
  _resetForTests();
  vi.stubGlobal('fetch', vi.fn(async (url: string) => {
    if (url.includes('/api/opc/auth/me')) {
      return Response.json({ company: { id: 'co1', name: '测试公司' } });
    }
    return Response.json({ items: [
      { id: 'e1', name: '文案', title: '内容运营', system_prompt: '负责文案', status: 'idle' },
      { id: 'e2', name: '分析', title: '数据分析师', system_prompt: '负责数据', status: 'idle' },
      { id: 'e3', name: '视觉', title: '视觉设计师', system_prompt: '负责视觉', status: 'idle' },
    ] });
  }));
});

afterEach(() => {
  vi.unstubAllGlobals();
  _resetForTests();
  process.chdir(originalCwd);
  rmSync(dir, { recursive: true, force: true });
});

const config = { provider: 'openai' as const, model: 'gpt-test', apiKey: 'test-key' };

describe('公司真实聊天', () => {
  it('单聊任务也调集相关员工、汇总成果并在下一轮携带上下文', async () => {
    const prompts: string[] = [];
    const callImpl = async function* (_provider: string, input: ProviderInput) {
      if (input.systemPrompt.includes('编排者')) {
        yield { type: 'text-delta' as const, text: JSON.stringify({
          intent: 'task', strategy: 'pipeline', tasks: [
            { agentId: 'e1', title: '撰写文案', prompt: '先写推广文案' },
            { agentId: 'e2', title: '数据复盘', prompt: '基于文案做数据复盘', depends_on: ['e1'] },
          ],
        }) };
        return;
      }
      prompts.push(input.userMessage);
      if (input.systemPrompt.includes('汇总员工')) {
        yield { type: 'text-delta' as const, text: '总经理最终汇总' };
      } else {
        yield { type: 'text-delta' as const, text: input.userMessage.includes('数据复盘') ? '员工分析成果' : '员工文案成果' };
      }
    };
    const conversation = createOpcConversation('co1', 'single');
    const first = await runOpcChatTurn({ conversationId: conversation.id, companyId: 'co1', content: '先写推广文案，再结合数据分析复盘', config, authorization: 'Bearer test', callImpl });
    expect(first.plan?.assignments.map(item => item.agent_id)).toEqual(['e1', 'e2']);
    expect(first.messages.filter(message => message.sender_kind === 'agent').map(message => message.sender_name)).toEqual(['文案', '分析']);
    expect(first.messages[0].channel).toBe('workflow');
    expect(new Set(first.messages.map(message => message.run_id)).size).toBe(1);
    expect(first.messages[0].metadata_json).toContain('撰写文案');
    expect(first.messages.filter(message => message.sender_kind === 'agent').every(message => message.channel === 'workflow' && message.status === 'done' && message.task_id && message.task_title)).toBe(true);
    expect(first.messages.at(-1)?.content).toBe('总经理最终汇总');
    expect(first.messages.at(-1)?.channel).toBe('chat');
    expect(prompts[1]).toContain('员工文案成果');

    await runOpcChatTurn({ conversationId: conversation.id, companyId: 'co1', content: '继续完善', config, authorization: 'Bearer test', callImpl });
    expect(prompts[3]).toContain('先写推广文案，再结合数据分析复盘');
    expect(prompts[3]).toContain('总经理最终汇总');
    expect(listOpcMessages(conversation.id).filter(message => message.sender_kind === 'agent')).toHaveLength(4);
  });

  it('总经理只选择相关员工，并按顺序交接真实产出', async () => {
    const prompts: string[] = [];
    const callImpl = async function* (_provider: string, input: ProviderInput) {
      if (input.systemPrompt.includes('编排者')) {
        yield { type: 'text-delta' as const, text: JSON.stringify({
          intent: 'task', strategy: 'pipeline', tasks: [
            { agentId: 'e1', title: '撰写文案', prompt: '先写获客文案' },
            { agentId: 'e2', title: '分析文案', prompt: '基于文案给出数据复盘', depends_on: ['e1'] },
          ],
        }) };
        return;
      }
      prompts.push(input.userMessage);
      yield { type: 'text-delta' as const, text: prompts.length === 1 ? '文案实际成果-unique' : '分析实际成果' };
    };
    const conversation = createOpcConversation('co1', 'group');
    const result = await runOpcChatTurn({ conversationId: conversation.id, companyId: 'co1', content: '写文案并分析', config, authorization: 'Bearer test', callImpl });
    expect(result.plan?.assignments.map((item) => item.agent_id)).toEqual(['e1', 'e2']);
    expect(result.messages.filter((message) => message.sender_kind === 'agent')).toHaveLength(2);
    expect(prompts[1]).toContain('文案实际成果-unique');
    expect(listOpcMessages(conversation.id).some((message) => message.sender_name === '视觉')).toBe(false);
  });

  it('公司知识包隔离，检索原文进入员工与总经理上下文', async () => {
    linkKnowledgePack('co1', 'pack-1');
    expect(companyOwnsKnowledgePack('co1', 'pack-1')).toBe(true);
    expect(companyOwnsKnowledgePack('co2', 'pack-1')).toBe(false);
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
      if (url.includes('/api/memory-bank/packs/pack-1/query')) {
        return Response.json({ data: { hits: [{ text: '北极星活动暗号是蓝山-7429', source: '活动规则.txt', score: 1 }] } });
      }
      return Response.json({ items: [{ id: 'e1', name: '文案', title: '内容运营', status: 'idle' }] });
    }));
    const prompts: string[] = [];
    const callImpl = async function* (_provider: string, input: ProviderInput) {
      prompts.push(input.userMessage);
      if (input.systemPrompt.includes('编排者')) {
        yield { type: 'text-delta' as const, text: JSON.stringify({ intent: 'task', strategy: 'single', tasks: [{ agentId: 'e1', title: '回答暗号', prompt: '根据资料回答' }] }) };
      } else {
        yield { type: 'text-delta' as const, text: '暗号是蓝山-7429' };
      }
    };
    const conversation = createOpcConversation('co1', 'single');
    const events: Array<{ type: string; activity?: { name: string; status: string } }> = [];
    await runOpcChatTurn({
      conversationId: conversation.id, companyId: 'co1', content: '活动暗号是什么', config,
      authorization: 'Bearer test', callImpl, onEvent: event => events.push(event),
      embeddingHeaders: { 'X-Embedding-Key': 'request-only-key', 'X-Embedding-Model': 'test-embedding' },
    });
    expect(prompts.length).toBeGreaterThanOrEqual(3);
    expect(prompts.every(prompt => prompt.includes('蓝山-7429'))).toBe(true);
    expect(prompts.every(prompt => prompt.includes('活动规则.txt'))).toBe(true);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining('/api/memory-bank/packs/pack-1/query'), expect.objectContaining({
      headers: expect.objectContaining({ 'X-Embedding-Key': 'request-only-key', 'X-Embedding-Model': 'test-embedding' }),
    }));
    expect(events.filter(event => event.type === 'activity' && event.activity?.name === 'knowledge_search').map(event => event.activity?.status)).toEqual(['running', 'done']);
    expect(events.some(event => event.type === 'activity' && event.activity?.name === 'manager_planning')).toBe(true);
    expect(events.some(event => event.type === 'activity' && event.activity?.name === 'employee_dispatch')).toBe(true);
    const storedActivities = listOpcMessages(conversation.id).filter(message => message.sender_kind === 'system');
    expect(storedActivities.length).toBeGreaterThanOrEqual(3);
    expect(storedActivities.every(message => message.channel === 'workflow' && message.metadata_json?.includes('"activity"'))).toBe(true);
  });

  it('规划期间持续发送累计 thinking，且在 done 前完成跨 chunk 更新', async () => {
    const callImpl = async function* (_provider: string, input: ProviderInput) {
      if (input.systemPrompt.includes('编排者')) {
        const json = JSON.stringify({
          intent: 'task', strategy: 'expert',
          tasks: [{ agentId: 'e1', title: '撰写文案', prompt: '写推广文案' }],
        });
        yield { type: 'text-delta' as const, text: '<sf:think' };
        yield { type: 'text-delta' as const, text: 'ing>先分析' };
        yield { type: 'text-delta' as const, text: '目标，再选择' };
        yield { type: 'text-delta' as const, text: `文案</sf:thinking>${json}` };
        return;
      }
      yield { type: 'text-delta' as const, text: '实际成果' };
    };
    const conversation = createOpcConversation('co1', 'single');
    const events: Array<{
      type: string;
      activity?: { id: string; name: string; status: string; thinking?: string };
    }> = [];
    const result = await runOpcChatTurn({
      conversationId: conversation.id, companyId: 'co1', content: '写推广文案', config,
      authorization: 'Bearer test', callImpl, onEvent: event => events.push(event),
    });
    const planning = events.filter(event => event.type === 'activity' && event.activity?.name === 'manager_planning');
    const runningThinking = planning.filter(event => event.activity?.status === 'running' && event.activity.thinking);
    const doneIndex = planning.findIndex(event => event.activity?.status === 'done');
    expect(runningThinking.map(event => event.activity?.thinking)).toEqual([
      '先分析', '先分析目标，再选择', '先分析目标，再选择文案',
    ]);
    expect(new Set(planning.map(event => event.activity?.id)).size).toBe(1);
    expect(doneIndex).toBeGreaterThan(-1);
    expect(planning.slice(0, doneIndex).filter(event => event.activity?.thinking)).toHaveLength(3);
    expect(planning[doneIndex]?.activity?.thinking).toBe('先分析目标，再选择文案');
    expect(result.messages[0]?.thinking).toBe('先分析目标，再选择文案');
    expect(JSON.stringify(result.plan)).not.toContain('sf:thinking');
    expect(result.messages[0]?.content).not.toContain('sf:thinking');
  });

  it('旧消息表先补字段再创建轮次索引', () => {
    getDb().exec(`CREATE TABLE opc_chat_messages (
      id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, sender_kind TEXT NOT NULL,
      sender_name TEXT NOT NULL, agent_id TEXT, content TEXT NOT NULL,
      channel TEXT NOT NULL DEFAULT 'chat', created_at TEXT NOT NULL
    )`);
    expect(() => listOpcMessages('legacy')).not.toThrow();
    const columns = getDb().prepare('PRAGMA table_info(opc_chat_messages)').all() as Array<{ name: string }>;
    expect(columns.map(column => column.name)).toEqual(expect.arrayContaining(['run_id', 'task_id', 'thinking', 'metadata_json']));
  });

  it('删除按公司隔离且级联删除消息', () => {
    const conversation = createOpcConversation('co1', 'single');
    expect(getOpcConversation(conversation.id, 'co2')).toBeNull();
    expect(deleteOpcConversation(conversation.id, 'co2')).toBe(false);
    expect(deleteOpcConversation(conversation.id, 'co1')).toBe(true);
    expect(listOpcMessages(conversation.id)).toEqual([]);
  });
});
