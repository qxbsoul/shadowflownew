import { randomUUID } from 'node:crypto';
import { getDb } from './sqlite';
import type { OpcChatActivity } from '../services/opc-chat-stream';

export type OpcChatKind = 'single' | 'group';
export type OpcMessageKind = 'user' | 'ceo' | 'agent' | 'system';
export type OpcMessageChannel = 'chat' | 'workflow';
export type OpcMessageStatus = 'pending' | 'waiting_approval' | 'running' | 'done' | 'failed' | 'blocked' | 'rejected';
export type OpcApprovalDecision = 'approve' | 'reject' | 'custom';
export type OpcApprovalOutcome = 'continue' | 'reject';

export interface OpcChatApproval {
  id: string;
  company_id: string;
  conversation_id: string;
  run_id: string;
  task_id: string;
  task_title: string;
  status: 'pending' | 'decided';
  decision: OpcApprovalDecision | null;
  custom_text: string;
  outcome: OpcApprovalOutcome | null;
  created_at: string;
  decided_at: string | null;
}

export interface OpcChatMessageMetadata {
  strategy?: string;
  source?: string;
  assignments?: Array<{ agent_id: string; name: string; title: string; depends_on: string[] }>;
  dag?: { nodes: Array<Record<string, unknown>> };
  activity?: OpcChatActivity;
  approval?: OpcChatApproval;
  [key: string]: unknown;
}

export interface OpcConversation {
  id: string;
  company_id: string;
  kind: OpcChatKind;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface OpcChatMessage {
  id: string;
  conversation_id: string;
  sender_kind: OpcMessageKind;
  sender_name: string;
  agent_id: string | null;
  content: string;
  channel: OpcMessageChannel;
  run_id: string | null;
  task_id: string | null;
  task_title: string | null;
  thinking: string;
  status: OpcMessageStatus | null;
  duration_ms: number | null;
  metadata_json: string | null;
  created_at: string;
}

function init(): void {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS opc_chat_conversations (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      kind TEXT NOT NULL CHECK(kind IN ('single','group')),
      title TEXT NOT NULL DEFAULT '新对话',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_opc_chat_company ON opc_chat_conversations(company_id, updated_at);
    CREATE TABLE IF NOT EXISTS opc_chat_messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      sender_kind TEXT NOT NULL,
      sender_name TEXT NOT NULL,
      agent_id TEXT,
      content TEXT NOT NULL,
      channel TEXT NOT NULL DEFAULT 'chat',
      run_id TEXT,
      task_id TEXT,
      task_title TEXT,
      thinking TEXT NOT NULL DEFAULT '',
      status TEXT,
      duration_ms INTEGER,
      metadata_json TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY(conversation_id) REFERENCES opc_chat_conversations(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_opc_chat_messages ON opc_chat_messages(conversation_id, created_at);
  `);
  const columns = db.prepare('PRAGMA table_info(opc_chat_messages)').all() as Array<{ name: string }>;
  const additions: Array<[string, string]> = [
    ['channel', "TEXT NOT NULL DEFAULT 'chat'"],
    ['run_id', 'TEXT'],
    ['task_id', 'TEXT'],
    ['task_title', 'TEXT'],
    ['thinking', "TEXT NOT NULL DEFAULT ''"],
    ['status', 'TEXT'],
    ['duration_ms', 'INTEGER'],
    ['metadata_json', 'TEXT'],
  ];
  for (const [name, definition] of additions) {
    if (!columns.some(column => column.name === name)) {
      db.exec(`ALTER TABLE opc_chat_messages ADD COLUMN ${name} ${definition}`);
    }
  }
  db.exec('CREATE INDEX IF NOT EXISTS idx_opc_chat_runs ON opc_chat_messages(conversation_id, run_id, created_at)');
}

export function listOpcConversations(companyId: string): OpcConversation[] {
  init();
  return getDb().prepare('SELECT * FROM opc_chat_conversations WHERE company_id = ? ORDER BY updated_at DESC').all(companyId) as OpcConversation[];
}

export function getOpcConversation(id: string, companyId: string): OpcConversation | null {
  init();
  return (getDb().prepare('SELECT * FROM opc_chat_conversations WHERE id = ? AND company_id = ?').get(id, companyId) as OpcConversation | undefined) ?? null;
}

export function createOpcConversation(companyId: string, kind: OpcChatKind, title = '新对话'): OpcConversation {
  init();
  const now = new Date().toISOString();
  const row: OpcConversation = { id: randomUUID(), company_id: companyId, kind, title, created_at: now, updated_at: now };
  getDb().prepare('INSERT INTO opc_chat_conversations (id,company_id,kind,title,created_at,updated_at) VALUES (?,?,?,?,?,?)')
    .run(row.id, row.company_id, row.kind, row.title, row.created_at, row.updated_at);
  return row;
}

export function deleteOpcConversation(id: string, companyId: string): boolean {
  init();
  return getDb().prepare('DELETE FROM opc_chat_conversations WHERE id = ? AND company_id = ?').run(id, companyId).changes > 0;
}

export function listOpcMessages(conversationId: string): OpcChatMessage[] {
  init();
  return getDb().prepare('SELECT * FROM opc_chat_messages WHERE conversation_id = ? ORDER BY created_at, rowid').all(conversationId) as OpcChatMessage[];
}

export function appendOpcMessage(
  conversationId: string,
  input: {
    sender_kind: OpcMessageKind;
    sender_name: string;
    agent_id?: string | null;
    content: string;
    channel?: OpcMessageChannel;
    run_id?: string | null;
    task_id?: string | null;
    task_title?: string | null;
    thinking?: string;
    status?: OpcMessageStatus | null;
    duration_ms?: number | null;
    metadata?: OpcChatMessageMetadata | null;
  },
): OpcChatMessage {
  init();
  const now = new Date().toISOString();
  const row: OpcChatMessage = {
    id: randomUUID(), conversation_id: conversationId, sender_kind: input.sender_kind,
    sender_name: input.sender_name, agent_id: input.agent_id ?? null, content: input.content,
    channel: input.channel ?? 'chat', run_id: input.run_id ?? null, task_id: input.task_id ?? null,
    task_title: input.task_title ?? null, thinking: input.thinking ?? '', status: input.status ?? null,
    duration_ms: input.duration_ms ?? null, metadata_json: input.metadata ? JSON.stringify(input.metadata) : null,
    created_at: now,
  };
  const db = getDb();
  db.transaction(() => {
    db.prepare('INSERT INTO opc_chat_messages (id,conversation_id,sender_kind,sender_name,agent_id,content,channel,run_id,task_id,task_title,thinking,status,duration_ms,metadata_json,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(row.id, row.conversation_id, row.sender_kind, row.sender_name, row.agent_id, row.content, row.channel, row.run_id, row.task_id, row.task_title, row.thinking, row.status, row.duration_ms, row.metadata_json, row.created_at);
    db.prepare('UPDATE opc_chat_conversations SET updated_at = ? WHERE id = ?').run(now, conversationId);
  })();
  return row;
}

export function renameOpcConversation(id: string, title: string): void {
  init();
  getDb().prepare('UPDATE opc_chat_conversations SET title = ? WHERE id = ?').run(title.slice(0, 40), id);
}


function initApprovals(): void {
  init();
  getDb().exec(`
    CREATE TABLE IF NOT EXISTS opc_chat_approvals (
      id TEXT PRIMARY KEY,
      company_id TEXT NOT NULL,
      conversation_id TEXT NOT NULL,
      run_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      task_title TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('pending','decided')),
      decision TEXT,
      custom_text TEXT NOT NULL DEFAULT '',
      outcome TEXT,
      created_at TEXT NOT NULL,
      decided_at TEXT,
      UNIQUE(run_id, task_id),
      FOREIGN KEY(conversation_id) REFERENCES opc_chat_conversations(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_opc_approvals_company ON opc_chat_approvals(company_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_opc_approvals_conversation ON opc_chat_approvals(conversation_id, run_id, created_at);
  `);
}

export function createOpcApproval(input: {
  company_id: string;
  conversation_id: string;
  run_id: string;
  task_id: string;
  task_title: string;
}): OpcChatApproval {
  initApprovals();
  const row: OpcChatApproval = {
    id: randomUUID(), ...input, status: 'pending', decision: null, custom_text: '',
    outcome: null, created_at: new Date().toISOString(), decided_at: null,
  };
  getDb().prepare(`INSERT INTO opc_chat_approvals
    (id,company_id,conversation_id,run_id,task_id,task_title,status,decision,custom_text,outcome,created_at,decided_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(row.id, row.company_id, row.conversation_id, row.run_id, row.task_id, row.task_title,
      row.status, row.decision, row.custom_text, row.outcome, row.created_at, row.decided_at);
  return row;
}

export function getOpcApproval(id: string, companyId: string): OpcChatApproval | null {
  initApprovals();
  return (getDb().prepare('SELECT * FROM opc_chat_approvals WHERE id = ? AND company_id = ?')
    .get(id, companyId) as OpcChatApproval | undefined) ?? null;
}

export function decideOpcApproval(
  id: string,
  companyId: string,
  decision: OpcApprovalDecision,
  customText: string,
  outcome: OpcApprovalOutcome,
): OpcChatApproval | null {
  initApprovals();
  const decidedAt = new Date().toISOString();
  const result = getDb().prepare(`UPDATE opc_chat_approvals
    SET status = 'decided', decision = ?, custom_text = ?, outcome = ?, decided_at = ?
    WHERE id = ? AND company_id = ? AND status = 'pending'`)
    .run(decision, customText, outcome, decidedAt, id, companyId);
  return result.changes === 1 ? getOpcApproval(id, companyId) : null;
}

export function listOpcApprovals(conversationId: string): OpcChatApproval[] {
  initApprovals();
  return getDb().prepare('SELECT * FROM opc_chat_approvals WHERE conversation_id = ? ORDER BY created_at, rowid')
    .all(conversationId) as OpcChatApproval[];
}

export function listOpcLogConversations(
  companyId: string,
  limit: number,
  cursor?: { updated_at: string; id: string },
): OpcConversation[] {
  init();
  const db = getDb();
  if (cursor) {
    return db.prepare(`SELECT * FROM opc_chat_conversations
      WHERE company_id = ? AND (updated_at < ? OR (updated_at = ? AND id < ?))
      ORDER BY updated_at DESC, id DESC LIMIT ?`)
      .all(companyId, cursor.updated_at, cursor.updated_at, cursor.id, limit) as OpcConversation[];
  }
  return db.prepare(`SELECT * FROM opc_chat_conversations
    WHERE company_id = ? ORDER BY updated_at DESC, id DESC LIMIT ?`)
    .all(companyId, limit) as OpcConversation[];
}
