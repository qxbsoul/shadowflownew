import { useEffect, useState } from 'react';
import { useWorkbench } from '../store';
import ProjectAuditPanel from './ProjectAuditPanel';

export default function ModalHost() {
  const { modal, closeModal } = useWorkbench();

  useEffect(() => {
    if (!modal) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeModal();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [modal, closeModal]);

  if (!modal) return null;
  const wide = modal.kind === 'preview-deliverable';

  return (
    <div
      className="modal-mask show"
      onClick={e => {
        if (e.target === e.currentTarget) closeModal();
      }}
    >
      <div className={wide ? 'modal wide' : 'modal'} role="dialog" aria-modal="true" aria-label={TITLE[modal.kind]}>
        <div className="modal-head">
          <h3>{TITLE[modal.kind]}</h3>
          <button className="modal-x" onClick={closeModal}>
            关闭
          </button>
        </div>
        <ModalBody modal={modal} />
      </div>
    </div>
  );
}

const TITLE: Record<string, string> = {
  'new-project': '新建项目',
  'new-dept': '新建部门',
  'rename-dept': '重命名部门',
  'delete-dept': '删除部门',
  'new-position': '新建岗位',
  'delete-position': '删除岗位',
  'new-staff': '添加员工',
  'delete-staff': '删除员工',
  'new-task': '新建定时任务',
  'delete-task': '删除定时任务',
  'delete-conversation': '删除对话',
  'decide-approval': '人工审批',
  'delete-deliverable': '删除项目',
  'preview-deliverable': '交付物预览',
};

function ModalBody({ modal }: { modal: NonNullable<ReturnType<typeof useWorkbench>['modal']> }) {
  switch (modal.kind) {
    case 'new-project':
      return <NewProjectModal />;
    case 'new-dept':
      return <NewDeptModal />;
    case 'rename-dept':
      return <RenameDeptModal deptId={modal.deptId} />;
    case 'delete-dept':
      return <DeleteDeptModal deptId={modal.deptId} />;
    case 'new-position':
      return <NewPositionModal deptId={modal.deptId} />;
    case 'delete-position':
      return <DeletePositionModal positionId={modal.positionId} />;
    case 'new-staff':
      return <NewStaffModal positionId={modal.positionId} />;
    case 'delete-staff':
      return <DeleteStaffModal staffId={modal.staffId} />;
    case 'new-task':
      return <NewTaskModal />;
    case 'delete-task':
      return <DeleteTaskModal taskId={modal.taskId} />;
    case 'delete-conversation':
      return <DeleteConversationModal conversationId={modal.conversationId} />;
    case 'decide-approval':
      return <DecideApprovalModal approvalId={modal.approvalId} decision={modal.decision} />;
    case 'delete-deliverable':
      return <DeleteDeliverableModal deliverableId={modal.deliverableId} />;
    case 'preview-deliverable':
      return <PreviewDeliverableModal deliverableId={modal.deliverableId} />;
  }
}

function NewProjectModal() {
  const { createAndRunProject, closeModal, toast, setView, gwStatus } = useWorkbench();
  const [name, setName] = useState('');
  const [clientName, setClientName] = useState('');
  const [goal, setGoal] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Awaited<ReturnType<typeof createAndRunProject>> | null>(null);

  const submit = async () => {
    if (goal.trim().length < 4) return toast('请至少用一句话描述项目目标');
    setBusy(true);
    try {
      setResult(await createAndRunProject({ name: name.trim(), goal: goal.trim(), clientName: clientName.trim() }));
    } catch {
      // store 已如实记录接口错误，表单保留供修正重试。
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="modal-body">
        <div className="form-group"><label className="form-label" htmlFor="project-name">项目名称（可选）</label><input id="project-name" className="form-input" value={name} disabled={busy || Boolean(result)} onChange={event => setName(event.target.value)} placeholder="未填写时由后端按目标命名" /></div>
        <div className="form-group"><label className="form-label" htmlFor="project-client">客户名称（可选）</label><input id="project-client" className="form-input" value={clientName} disabled={busy || Boolean(result)} onChange={event => setClientName(event.target.value)} placeholder="默认：内部" /></div>
        <div className="form-group"><label className="form-label" htmlFor="project-goal">项目目标</label><textarea id="project-goal" className="form-area" value={goal} disabled={busy || Boolean(result)} onChange={event => setGoal(event.target.value)} placeholder="说明业务目标、背景和期望交付内容" /></div>
        <div className="empty-tip">提交后会创建项目、自动拆解任务并立即执行，所有结果均来自后端。</div>
        {result && <div className={result.project.status === 'failed' ? 'project-run-result failed' : 'project-run-result'} role="status">
          <strong>{result.stopped === 'approval' ? '项目已暂停，等待人工审批' : result.project.status === 'delivered' ? '项目已完成交付' : result.project.status === 'failed' ? '项目执行失败' : `项目状态：${result.project.status}`}</strong>
          <span>项目编号：{result.project.id}</span>
          {result.stopped === 'approval' && <span>待审批事项：{result.pending_approvals.map(item => item.title).join('、') || '请前往人工审批查看'}</span>}
          {result.project.status === 'failed' && <span>{result.tasks.filter(item => item.status === 'failed').map(item => `${item.title}：${item.output?.text || '未返回失败详情'}`).join('；') || '后端未返回任务失败详情'}</span>}
        </div>}
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>{result ? '关闭' : '取消'}</button>
        {result?.stopped === 'approval' && <button className="btn btn-dark btn-sm" onClick={() => { closeModal(); setView('approvals'); }}>前往人工审批</button>}
        {result && result.project.status !== 'failed' && result.stopped !== 'approval' && <button className="btn btn-dark btn-sm" onClick={() => { closeModal(); setView('deliverables'); }}>查看交付记录</button>}
        {!result && <button className="btn btn-primary btn-sm" disabled={busy || gwStatus !== 'ok'} onClick={() => void submit()}>{busy ? '正在创建并执行…' : '创建并运行项目'}</button>}
      </div>
    </>
  );
}

function DeleteConversationModal({ conversationId }: { conversationId: string }) {
  const { conversations, deleteConversation, closeModal } = useWorkbench();
  const [busy, setBusy] = useState(false);
  const conversation = conversations.find(item => item.id === conversationId);
  const remove = async () => {
    setBusy(true);
    try { await deleteConversation(conversationId); } catch { setBusy(false); }
  };
  return (
    <>
      <div className="modal-body">
        <div className="preview-box">确认删除「<b>{conversation?.title ?? '这个对话'}</b>」？对话消息将一并删除，公司项目和交付成果不受影响。</div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" onClick={closeModal} disabled={busy}>取消</button>
        <button className="btn btn-danger btn-sm" onClick={() => void remove()} disabled={busy}>{busy ? '删除中' : '确认删除'}</button>
      </div>
    </>
  );
}

function useOrgSubmit() {
  const [busy, setBusy] = useState(false);
  const submit = async (operation: () => Promise<void>) => {
    if (busy) return;
    setBusy(true);
    try {
      await operation();
    } catch {
      // store 已展示真实错误，弹窗保留供修正后重试。
    } finally {
      setBusy(false);
    }
  };
  return { busy, submit };
}

/* ─────────── 部门 ─────────── */

function NewDeptModal() {
  const { createDept, closeModal, toast } = useWorkbench();
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="form-group">
          <label className="form-label">部门名称</label>
          <input className="form-input" value={name} disabled={busy} onChange={e => setName(e.target.value)} placeholder="例如：渠道增长部" />
        </div>
        <div className="form-group">
          <label className="form-label">说明（可选）</label>
          <input className="form-input" value={desc} disabled={busy} onChange={e => setDesc(e.target.value)} placeholder="这个部门负责什么业务" />
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-dark btn-sm" disabled={busy} onClick={() => {
          if (!name.trim()) return toast('请填写部门名称');
          void submit(() => createDept(name.trim(), desc.trim()));
        }}>
          {busy ? '创建中…' : '创建部门'}
        </button>
      </div>
    </>
  );
}

function RenameDeptModal({ deptId }: { deptId: string }) {
  const { org, renameDept, closeModal, toast } = useWorkbench();
  const dept = org.departments.find(d => d.id === deptId);
  const [name, setName] = useState(dept?.name ?? '');
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="form-group">
          <label className="form-label">部门名称</label>
          <input className="form-input" value={name} disabled={busy} onChange={e => setName(e.target.value)} />
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-dark btn-sm" disabled={busy} onClick={() => {
          if (!name.trim()) return toast('请填写部门名称');
          void submit(() => renameDept(deptId, name.trim()));
        }}>
          {busy ? '保存中…' : '保存'}
        </button>
      </div>
    </>
  );
}

function DeleteDeptModal({ deptId }: { deptId: string }) {
  const { org, deleteDept, closeModal } = useWorkbench();
  const dept = org.departments.find(d => d.id === deptId);
  const posIds = org.positions.filter(p => p.deptId === deptId).map(p => p.id);
  const staffN = org.staff.filter(s => posIds.includes(s.positionId)).length;
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          确认删除「<b>{dept?.name}</b>」？将真实移除其下 <b>{posIds.length}</b> 个岗位与 <b>{staffN}</b> 名岗位员工，再删除部门。此操作不可撤销。
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void submit(() => deleteDept(deptId))}>
          {busy ? '删除中…' : '确认删除'}
        </button>
      </div>
    </>
  );
}

/* ─────────── 岗位 ─────────── */

function NewPositionModal({ deptId }: { deptId?: string }) {
  const { org, createPosition, closeModal, toast } = useWorkbench();
  const [name, setName] = useState('');
  const [dept, setDept] = useState(deptId ?? org.departments[0]?.id ?? '');
  const [managerId, setManagerId] = useState('p-ceo');
  const [soul, setSoul] = useState('');
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="form-group">
          <label className="form-label">岗位名称</label>
          <input className="form-input" value={name} disabled={busy} onChange={e => setName(e.target.value)} placeholder="例如：增长运营专员" />
        </div>
        <div className="form-group">
          <label className="form-label">所属部门</label>
          <select className="form-select" value={dept} disabled={busy} onChange={e => setDept(e.target.value)}>
            {org.departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">汇报对象</label>
          <select className="form-select" value={managerId} disabled={busy} onChange={e => setManagerId(e.target.value)}>
            {org.positions.filter(p => !p.root).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            <option value="p-ceo">总经理（公司负责人）</option>
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">职责提示词（岗位灵魂）</label>
          <textarea className="form-area" value={soul} disabled={busy} onChange={e => setSoul(e.target.value)} placeholder="描述这个岗位负责什么、怎么干活、交付什么" />
        </div>
        <div className="empty-tip">将创建真实岗位员工，初始姓名为「岗位名·待入职」。</div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-dark btn-sm" disabled={busy} onClick={() => {
          if (!name.trim()) return toast('请填写岗位名称');
          void submit(() => createPosition({ name: name.trim(), deptId: dept, managerId, soul }));
        }}>
          {busy ? '创建中…' : '创建岗位'}
        </button>
      </div>
    </>
  );
}

function DeletePositionModal({ positionId }: { positionId: string }) {
  const { org, deletePosition, closeModal } = useWorkbench();
  const p = org.positions.find(x => x.id === positionId);
  const n = org.staff.filter(s => s.positionId === positionId).length;
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          确认删除岗位「<b>{p?.name}</b>」？其下 <b>{n}</b> 名岗位员工将同时被真实移除。此操作不可撤销。
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void submit(() => deletePosition(positionId))}>
          {busy ? '删除中…' : '确认删除'}
        </button>
      </div>
    </>
  );
}

/* ─────────── 员工 ─────────── */

function NewStaffModal({ positionId }: { positionId?: string }) {
  const { org, createStaff, closeModal, toast } = useWorkbench();
  const [name, setName] = useState('');
  const [pos, setPos] = useState(positionId ?? org.positions.find(p => !p.root)?.id ?? '');
  const [managerId, setManagerId] = useState('p-ceo');
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="form-group">
          <label className="form-label">姓名 / 花名</label>
          <input className="form-input" value={name} disabled={busy} onChange={e => setName(e.target.value)} placeholder="例如：小林" />
        </div>
        <div className="form-group">
          <label className="form-label">所属岗位</label>
          <select className="form-select" value={pos} disabled={busy} onChange={e => setPos(e.target.value)}>
            {org.positions.filter(p => !p.root).map(p => (
              <option key={p.id} value={p.id}>{p.name}（{org.departments.find(d => d.id === p.deptId)?.name || '—'}）</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">汇报对象（岗位）</label>
          <select className="form-select" value={managerId} disabled={busy} onChange={e => setManagerId(e.target.value)}>
            {org.positions.filter(p => !p.root).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            <option value="p-ceo">总经理（公司负责人）</option>
          </select>
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-dark btn-sm" disabled={busy} onClick={() => {
          if (!name.trim()) return toast('请填写姓名');
          void submit(() => createStaff({ name: name.trim(), positionId: pos, managerId }));
        }}>
          {busy ? '添加中…' : '添加'}
        </button>
      </div>
    </>
  );
}

function DeleteStaffModal({ staffId }: { staffId: string }) {
  const { org, deleteStaff, closeModal } = useWorkbench();
  const s = org.staff.find(x => x.id === staffId);
  const [reassignTo, setReassignTo] = useState('');
  const { busy, submit } = useOrgSubmit();

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">确认移除员工「<b>{s?.name}</b>」？</div>
        <div className="form-group" style={{ marginTop: '14px' }}>
          <label className="form-label">未完成任务接手人（如有任务则必选）</label>
          <select className="form-select" value={reassignTo} disabled={busy} onChange={event => setReassignTo(event.target.value)}>
            <option value="">不指定；有未完成任务时取消操作</option>
            {org.staff.filter(staff => staff.id !== staffId).map(staff => <option key={staff.id} value={staff.id}>{staff.name}</option>)}
          </select>
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void submit(() => deleteStaff(staffId, reassignTo || undefined))}>
          {busy ? '移除中…' : '确认移除'}
        </button>
      </div>
    </>
  );
}

/* ─────────── 定时任务 ─────────── */

function NewTaskModal() {
  const { org, createTask, closeModal, toast } = useWorkbench();
  const [name, setName] = useState('');
  const [freq, setFreq] = useState('每天');
  const [time, setTime] = useState('09:00');
  const [runDate, setRunDate] = useState('');
  const [weekDay, setWeekDay] = useState('1');
  const [monthDay, setMonthDay] = useState('1');
  const enabledPositions = org.positions.filter(p => !p.root && p.enabled);
  const [position, setPosition] = useState(enabledPositions[0]?.id ?? '');

  return (
    <>
      <div className="modal-body">
        <div className="form-group">
          <label className="form-label">任务名称</label>
          <input
            className="form-input"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="例如：每天早上 9 点生成行业简报"
          />
        </div>
        <div className="form-group">
          <label className="form-label">执行频率</label>
          <select className="form-select" value={freq} onChange={e => setFreq(e.target.value)}>
            <option>每天</option>
            <option>每周</option>
            <option>每月</option>
            <option>一次性</option>
          </select>
          <div style={{ fontSize: '10.5px', color: 'var(--muted)', marginTop: '5px' }}>
            {freq === '一次性' ? '将在指定日期和时间执行一次' : '按此周期自动重复执行'}
          </div>
        </div>
        {freq === '一次性' && (
          <div className="form-group">
            <label className="form-label">执行日期</label>
            <input className="form-input" type="date" value={runDate} onChange={e => setRunDate(e.target.value)} />
          </div>
        )}
        {freq === '每周' && (
          <div className="form-group">
            <label className="form-label">星期</label>
            <select className="form-select" value={weekDay} onChange={e => setWeekDay(e.target.value)}>
              {['一', '二', '三', '四', '五', '六', '日'].map((day, index) => (
                <option key={day} value={index === 6 ? '0' : String(index + 1)}>星期{day}</option>
              ))}
            </select>
          </div>
        )}
        {freq === '每月' && (
          <div className="form-group">
            <label className="form-label">每月日期</label>
            <input className="form-input" type="number" min="1" max="28" value={monthDay} onChange={e => setMonthDay(e.target.value)} />
          </div>
        )}
        <div className="form-group">
          <label className="form-label">执行时间</label>
          <input className="form-input" type="time" value={time} onChange={e => setTime(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">负责岗位</label>
          <select className="form-select" value={position} onChange={e => setPosition(e.target.value)}>
            {enabledPositions.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" onClick={closeModal}>取消</button>
        <button
          className="btn btn-dark btn-sm"
          onClick={() => {
            if (!name.trim()) return toast('请填写任务名称');
            createTask({ title: name.trim(), freq, time: time || '09:00', position, runDate, weekDay, monthDay });
          }}
        >
          创建任务
        </button>
      </div>
    </>
  );
}

function DeleteTaskModal({ taskId }: { taskId: string }) {
  const { tasks, deleteTask, closeModal } = useWorkbench();
  const t = tasks.find(x => x.id === taskId);

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          确认删除「<b>{t?.title}</b>」？删除后不再自动执行。
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" onClick={closeModal}>
          取消
        </button>
        <button className="btn btn-danger btn-sm" onClick={() => deleteTask(taskId)}>
          确认删除
        </button>
      </div>
    </>
  );
}

/* ─────────── 人工审批 ─────────── */

function DecideApprovalModal({ approvalId, decision }: { approvalId: string; decision: 'approved' | 'rejected' }) {
  const { approvals, deliverables, decideApproval, closeModal, toast } = useWorkbench();
  const approval = approvals.find(item => item.id === approvalId);
  const project = deliverables.find(item => item.sourceId === approval?.project_id);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const approved = decision === 'approved';

  const submit = async () => {
    if (!approved && !note.trim()) return toast('驳回时请填写返工意见');
    setBusy(true);
    try {
      await decideApproval(approvalId, decision, note.trim());
      closeModal();
    } catch {
      // store 已展示真实 API 错误，弹窗保留供修正后重试。
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          <h4>{approval?.title ?? '审批事项'}</h4>
          <div style={{ fontSize: '11px', color: 'var(--muted)', margin: '4px 0 10px' }}>
            {project?.title ?? approval?.project_id ?? '公司项目'} · {approval?.payload?.by ?? '公司岗位'}
          </div>
          <div>{approval?.payload?.summary ?? '该审批没有额外交付摘要，请结合项目任务结果验收。'}</div>
          {approval?.payload?.summary?.includes('[simulated]') && (
            <div style={{ fontSize: '11px', color: 'var(--red)', marginTop: '10px' }}>
              无效历史记录：该摘要不是有效交付，不能作为验收依据。
            </div>
          )}
        </div>
        <div className="form-group" style={{ marginTop: '14px' }}>
          <label className="form-label">审批意见{approved ? '（可选）' : '（返工要求，必填）'}</label>
          <textarea
            className="form-area"
            value={note}
            onChange={event => setNote(event.target.value)}
            placeholder={approved ? '可填写验收说明' : '请说明需要修改的内容，任务将退回负责岗位返工'}
          />
        </div>
        <div style={{ fontSize: '11px', color: 'var(--muted)' }}>
          {approved ? '批准后会自动调用项目执行接口；若还有后续审批，项目会停在下一节点。' : '驳回后任务退回待执行，并自动按你的意见重新执行。'}
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className={approved ? 'btn btn-dark btn-sm' : 'btn btn-danger btn-sm'} disabled={busy} onClick={() => void submit()}>
          {busy ? '正在提交并执行…' : approved ? '批准并继续' : '确认驳回并返工'}
        </button>
      </div>
    </>
  );
}

/* ─────────── 交付物预览 / 删除 / 重试 ─────────── */

function DeleteDeliverableModal({ deliverableId }: { deliverableId: string }) {
  const { deliverables, deleteDeliverable, closeModal } = useWorkbench();
  const d = deliverables.find(item => item.id === deliverableId);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      await deleteDeliverable(deliverableId);
    } catch {
      // store 已展示真实 API 错误，弹窗保留供确认状态后重试。
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          确认删除项目「<b>{d?.title ?? deliverableId}</b>」？项目任务、审批记录和关联台账将一并删除，此操作不可撤销。商务订单项目需先走订单取消或归档流程。
        </div>
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>取消</button>
        <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void submit()}>
          {busy ? '正在删除…' : '确认删除'}
        </button>
      </div>
    </>
  );
}

function PreviewDeliverableModal({ deliverableId }: { deliverableId: string }) {
  const { deliverables, closeModal, openModal, toast, loadDeliverable, retryDeliverable, gwStatus } = useWorkbench();
  const d = deliverables.find(x => x.id === deliverableId);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (d?.sourceId && !d.contentLoaded) void loadDeliverable(deliverableId);
    // 项目状态变化后重新加载正文；contentLoaded 防止重复请求。
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deliverableId, d?.contentLoaded, d?.rawStatus]);
  if (!d) return null;

  const retry = async () => {
    setBusy(true);
    try {
      await retryDeliverable(deliverableId);
    } catch {
      // store 已展示真实 API 错误。
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="modal-body">
        <div className="preview-box">
          <h4>{d.title}</h4>
          <div style={{ fontSize: '11px', color: 'var(--muted)', marginBottom: '12px' }}>
            {d.type} · {d.client} · {d.time} · {d.status}
          </div>
          {d.contentLoaded && d.contentMode === 'error' && (
            <div style={{ fontSize: '11px', color: 'var(--red)', marginBottom: '12px' }}>
              无效历史记录：以下正文不是有效业务交付。
            </div>
          )}
          <div style={{ whiteSpace: 'pre-wrap', lineHeight: 1.75 }}>
            {d.contentLoaded
              ? d.content
              : gwStatus === 'ok'
                ? d.status === '已交付'
                  ? '正在从项目记录加载交付正文…'
                  : '项目尚未交付，当前没有可预览正文。'
                : '后端未连接，无法加载项目交付正文。'}
          </div>
        </div>
        {gwStatus === 'ok' && d.sourceId && <ProjectAuditPanel projectId={d.sourceId} refreshKey={d.rawStatus} />}
      </div>
      <div className="modal-foot">
        <button className="btn btn-ghost btn-sm" disabled={busy} onClick={closeModal}>关闭</button>
        {gwStatus === 'ok' && d.sourceId && (
          <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => openModal({ kind: 'delete-deliverable', deliverableId })}>
            删除项目
          </button>
        )}
        {gwStatus === 'ok' && d.sourceId && d.rawStatus === 'failed' && (
          <button className="btn btn-dark btn-sm" disabled={busy} onClick={() => void retry()}>
            {busy ? '正在重试…' : '重试失败任务'}
          </button>
        )}
        <button className="btn btn-dark btn-sm" disabled={busy || !d.contentLoaded || !d.content || d.contentMode === 'error' || d.status !== '已交付'} onClick={() => {
          const safeName = (d.title.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/g, '').slice(0, 80) || '交付成果') + '.md';
          const markdown = `# ${d.title}\n\n- 类型：${d.type}\n- 客户：${d.client}\n- 状态：${d.status}\n- 时间：${d.time}\n\n---\n\n${d.content ?? ''}\n`;
          const url = URL.createObjectURL(new Blob([markdown], { type: 'text/markdown;charset=utf-8' }));
          const anchor = document.createElement('a');
          anchor.href = url;
          anchor.download = safeName;
          document.body.appendChild(anchor);
          anchor.click();
          anchor.remove();
          window.setTimeout(() => URL.revokeObjectURL(url), 0);
          toast('Markdown 文件已生成');
        }}>
          下载 Markdown
        </button>
      </div>
    </>
  );
}
