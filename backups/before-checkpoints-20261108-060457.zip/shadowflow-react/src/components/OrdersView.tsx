import { useEffect, useState } from 'react';
import {
  cancelOrder,
  createOrder,
  getOrder,
  getProducts,
  type OrderDetailDto,
  type PayInfoDto,
  type ProductDto,
} from '../api';
import { useWorkbench } from '../store';

const STATUS_LABELS: Record<string, string> = {
  created: '已创建', pending_payment: '待支付', paid: '已支付', running: '交付中',
  delivered: '已交付', failed: '失败', cancelled: '已取消', refunded: '已退款',
};
const STEP_LABELS: Record<string, string> = {
  todo: '待执行', running: '执行中', review: '待审批', done: '已完成', failed: '失败', blocked: '已阻塞',
};

function timeText(value?: string): string {
  if (!value) return '未记录';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { hour12: false });
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

export default function OrdersView() {
  const { orders, ordersLoading, refreshOrders, setView, toast, gwStatus } = useWorkbench();
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [payInfo, setPayInfo] = useState<PayInfoDto | null>(null);
  const [productId, setProductId] = useState('');
  const [buyerName, setBuyerName] = useState('');
  const [contact, setContact] = useState('');
  const [requirement, setRequirement] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [productError, setProductError] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const [detail, setDetail] = useState<OrderDetailDto | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState('');
  const [cancelling, setCancelling] = useState(false);

  const loadProducts = async () => {
    setProductError('');
    try {
      const result = await getProducts();
      const available = result.items.filter(item => item.active !== false);
      setProducts(available);
      setPayInfo(result.pay);
      setProductId(previous => available.some(item => item.id === previous) ? previous : available[0]?.id ?? '');
    } catch (error) {
      setProductError(errorText(error));
    }
  };

  useEffect(() => { void loadProducts(); }, []);

  const loadDetail = async (id: string) => {
    if (!id) return;
    setSelectedId(id);
    setDetailLoading(true);
    setDetailError('');
    try {
      setDetail(await getOrder(id));
    } catch (error) {
      setDetail(null);
      setDetailError(errorText(error));
    } finally {
      setDetailLoading(false);
    }
  };

  const submit = async () => {
    if (!productId) return toast('请选择商品');
    if (requirement.trim().length < 4) return toast('请至少用一句话描述交付需求');
    setSubmitting(true);
    try {
      const result = await createOrder({
        product_id: productId,
        buyer_name: buyerName.trim(),
        contact: contact.trim(),
        requirement: requirement.trim(),
      });
      setRequirement('');
      await refreshOrders();
      toast(`订单已创建，当前状态：${STATUS_LABELS[result.order.status] ?? result.order.status}`);
      await loadDetail(result.order.id);
    } catch (error) {
      toast(`下单失败：${errorText(error)}`);
    } finally {
      setSubmitting(false);
    }
  };

  const cancel = async () => {
    if (!detail || detail.order.status !== 'pending_payment') return;
    setCancelling(true);
    try {
      await cancelOrder(detail.order.id);
      await refreshOrders();
      await loadDetail(detail.order.id);
      toast('待支付订单已取消');
    } catch (error) {
      toast(`取消订单失败：${errorText(error)}`);
    } finally {
      setCancelling(false);
    }
  };

  const refresh = async () => {
    try {
      await refreshOrders();
      if (selectedId) await loadDetail(selectedId);
      toast('订单状态已刷新');
    } catch (error) {
      toast(`订单刷新失败：${errorText(error)}`);
    }
  };

  const selectedProduct = products.find(item => item.id === productId);

  return (
    <div className="view-inner orders-view">
      <div className="view-head">
        <div><h2>公司订单</h2><p className="view-description">从真实商品下单，支付与交付状态完全由后端推进。</p></div>
        <button className="btn btn-ghost btn-sm" disabled={ordersLoading || gwStatus !== 'ok'} onClick={() => void refresh()}>{ordersLoading ? '正在读取…' : '刷新订单'}</button>
      </div>

      <div className="orders-layout">
        <section className="panel panel-pad order-create">
          <div className="chart-title">新建订单</div>
          <div className="form-group">
            <label className="form-label" htmlFor="order-product">商品</label>
            <select id="order-product" className="form-select" value={productId} disabled={submitting || !products.length} onChange={event => setProductId(event.target.value)}>
              {!products.length && <option value="">暂无可用商品</option>}
              {products.map(product => <option key={product.id} value={product.id}>{product.name} · ¥{(product.price_cents / 100).toFixed(2)}</option>)}
            </select>
          </div>
          {productError && <div className="inline-error" role="alert">{productError}<button className="btn btn-ghost btn-sm" onClick={() => void loadProducts()}>重试</button></div>}
          {selectedProduct && <div className="product-summary"><strong>{selectedProduct.summary}</strong><span>{selectedProduct.deliverable}</span><span>{selectedProduct.eta_hint}</span></div>}
          <div className="order-form-row">
            <div className="form-group"><label className="form-label" htmlFor="order-buyer">客户名称（可选）</label><input id="order-buyer" className="form-input" value={buyerName} disabled={submitting} onChange={event => setBuyerName(event.target.value)} /></div>
            <div className="form-group"><label className="form-label" htmlFor="order-contact">联系方式（可选）</label><input id="order-contact" className="form-input" value={contact} disabled={submitting} onChange={event => setContact(event.target.value)} /></div>
          </div>
          <div className="form-group"><label className="form-label" htmlFor="order-requirement">交付需求</label><textarea id="order-requirement" className="form-area" value={requirement} disabled={submitting} onChange={event => setRequirement(event.target.value)} placeholder="请描述目标、背景和期望交付内容" /></div>
          <div className="pay-info"><strong>支付配置</strong><span>{payInfo ? `${payInfo.configured ? '已配置' : '未配置'} · ${payInfo.provider || payInfo.mode || '未指定渠道'}` : '等待商品接口返回'}</span>{payInfo?.note && <p>{payInfo.note}</p>}<small>此处不提供模拟支付，订单仅在收到有效支付结果后进入交付。</small></div>
          <button className="btn btn-primary" disabled={submitting || !productId || !payInfo?.configured} onClick={() => void submit()}>{submitting ? '正在下单…' : '创建真实订单'}</button>
        </section>

        <section className="panel order-list-panel">
          <div className="order-section-head"><h3>订单列表</h3><span>{orders.length} 笔</span></div>
          <div className="order-list">
            {orders.map(order => <button key={order.id} className={selectedId === order.id ? 'order-list-item active' : 'order-list-item'} onClick={() => void loadDetail(order.id)}>
              <span className="order-list-title"><strong>{order.product_name || order.product_id}</strong><span className={`pill ${order.status === 'delivered' ? 'pill-ok' : order.status === 'failed' || order.status === 'cancelled' ? 'pill-err' : 'pill-wait'}`}>{STATUS_LABELS[order.status] ?? order.status}</span></span>
              <span className="order-list-meta">{order.id} · {timeText(order.created_at)}</span>
            </button>)}
            {!orders.length && !ordersLoading && <div className="empty-tip">暂无订单</div>}
          </div>
        </section>
      </div>

      <section className="panel panel-pad order-detail">
        <div className="order-section-head"><h3>订单详情与交付进度</h3>{detail && <button className="btn btn-ghost btn-sm" disabled={detailLoading} onClick={() => void loadDetail(detail.order.id)}>刷新详情</button>}</div>
        {!selectedId && <div className="empty-tip">选择一笔订单查看步骤和事件</div>}
        {detailLoading && <div className="empty-tip">正在读取订单详情…</div>}
        {detailError && <div className="inline-error" role="alert">{detailError}<button className="btn btn-ghost btn-sm" onClick={() => void loadDetail(selectedId)}>重试</button></div>}
        {detail && !detailLoading && <>
          <div className="order-detail-grid">
            <div><span>订单编号</span><strong>{detail.order.id}</strong></div><div><span>当前状态</span><strong>{STATUS_LABELS[detail.order.status] ?? detail.order.status}</strong></div>
            <div><span>商品</span><strong>{detail.order.product_name || detail.order.product_id}</strong></div><div><span>金额</span><strong>{detail.order.amount_cents === undefined ? '未返回' : `¥${(detail.order.amount_cents / 100).toFixed(2)}`}</strong></div>
          </div>
          <p className="order-requirement">{detail.order.requirement}</p>
          <div className="actions order-actions">
            {detail.order.status === 'pending_payment' && <button className="btn btn-danger btn-sm" disabled={cancelling} onClick={() => void cancel()}>{cancelling ? '正在取消…' : '取消待支付订单'}</button>}
            {detail.project && <button className="btn btn-dark btn-sm" onClick={() => setView('deliverables')}>查看关联交付（{detail.project.status}）</button>}
          </div>
          <div className="order-tracking-grid">
            <div><h4>项目步骤</h4>{detail.steps.length ? <ol className="order-steps">{detail.steps.map((step, index) => <li key={`${step.title}-${index}`}><span>{step.title}</span><small>{step.agent || '未分配'} · {STEP_LABELS[step.status] ?? step.status}</small></li>)}</ol> : <div className="empty-tip">支付完成后由后端创建项目步骤</div>}</div>
            <div><h4>订单事件</h4>{detail.events.length ? <ol className="order-events">{detail.events.map((event, index) => <li key={String(event.seq ?? index)}><span>{String(event.type ?? '未知事件')}</span><small>{timeText(typeof event.ts === 'string' ? event.ts : undefined)}</small></li>)}</ol> : <div className="empty-tip">暂无事件</div>}</div>
          </div>
        </>}
      </section>
    </div>
  );
}
