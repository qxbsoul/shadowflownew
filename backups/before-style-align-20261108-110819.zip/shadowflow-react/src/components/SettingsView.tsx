import { useEffect, useState, type FormEvent } from 'react';
import { hasStoredApiKey, MIMO_BASE_URL, MIMO_MODEL } from '../settings-storage';
import { testEmbeddingConnection } from '../api';
import {
  clearEmbeddingKey,
  DEFAULT_EMBEDDING,
  EMBEDDING_PROVIDERS,
  loadEmbeddingSettings,
  saveEmbeddingSettings,
  type EmbeddingProvider,
} from '../embedding-storage';
import { useWorkbench } from '../store';
import { loadToolSettings, saveToolSettings } from '../tool-storage';

type SettingsSection = 'general' | 'model' | 'embedding' | 'tools';

export function modelsForProvider<T extends { id: string; vendor: string }>(models: T[], provider: string): T[] {
  if (provider !== 'mimo') return [];
  return models.filter(item => item.vendor === 'MiMo' && item.id === MIMO_MODEL);
}

export default function SettingsView() {
  const { apiSettings, saveModelSettings, clearModelKey } = useWorkbench();
  const [section, setSection] = useState<SettingsSection>('general');
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [error, setError] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [embedding, setEmbedding] = useState(() => loadEmbeddingSettings());
  const [embeddingKey, setEmbeddingKey] = useState('');
  const [embeddingFeedback, setEmbeddingFeedback] = useState('');
  const [embeddingError, setEmbeddingError] = useState('');
  const [embeddingTesting, setEmbeddingTesting] = useState(false);
  const [toolSettings, setToolSettings] = useState(() => loadToolSettings());
  const [toolFeedback, setToolFeedback] = useState('');
  const hasKey = hasStoredApiKey('official', 'mimo');

  useEffect(() => {
    setApiKey('');
    setConfirmClear(false);
  }, [apiSettings]);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    setFeedback('');
    setError('');
    try {
      saveModelSettings({ mode: 'official', provider: 'mimo', model: MIMO_MODEL, baseUrl: MIMO_BASE_URL, apiKey });
      setApiKey('');
      setShowKey(false);
      setFeedback('MiMo 配置已保存到当前浏览器。');
    } catch {
      setError('浏览器存储不可用，本次配置未保存。请检查隐私模式或存储权限。');
    }
  };

  const clearKey = () => {
    if (!confirmClear) {
      setConfirmClear(true);
      setFeedback('再次点击“确认清除”才会移除密钥。');
      return;
    }
    clearModelKey({ mode: 'official', provider: 'mimo' });
    setApiKey('');
    setConfirmClear(false);
    setError('');
    setFeedback('密钥已从当前浏览器移除。');
  };

  const selectEmbeddingProvider = (provider: EmbeddingProvider) => {
    const preset = provider === 'custom' ? { baseUrl: '', models: [''] } : EMBEDDING_PROVIDERS[provider];
    setEmbedding(previous => ({
      ...previous, provider,
      baseUrl: provider === 'custom' ? previous.baseUrl : preset.baseUrl,
      model: provider === 'custom' ? previous.model : preset.models[0],
    }));
    setEmbeddingFeedback('');
    setEmbeddingError('');
  };
  const saveEmbedding = () => {
    setEmbeddingFeedback('');
    setEmbeddingError('');
    if (!embedding.baseUrl.trim() || !embedding.model.trim()) {
      setEmbeddingError('请填写完整的 Base URL 和模型名称。');
      return false;
    }
    if (!embedding.hasKey && !embeddingKey.trim()) {
      setEmbeddingError('请输入 Embedding API Key。');
      return false;
    }
    try {
      setEmbedding(saveEmbeddingSettings({ ...embedding, apiKey: embeddingKey }));
      setEmbeddingKey('');
      setEmbeddingFeedback('配置已保存；点击“测试连接”验证真实服务。');
      return true;
    } catch {
      setEmbeddingError('浏览器存储不可用，配置未保存。');
      return false;
    }
  };
  const testEmbedding = async () => {
    if (!saveEmbedding()) return;
    setEmbeddingTesting(true);
    setEmbeddingFeedback('');
    try {
      const result = await testEmbeddingConnection();
      setEmbeddingFeedback(`连接成功：${result.data.model}，返回 ${result.data.dimensions} 维向量。`);
    } catch (reason) {
      setEmbeddingError(reason instanceof Error ? reason.message : String(reason));
    } finally {
      setEmbeddingTesting(false);
    }
  };
  const saveTools = () => {
    saveToolSettings(toolSettings);
    setToolSettings(loadToolSettings());
    setToolFeedback('工具配置已保存。员工还需在组织架构中获得对应工具权限。');
  };

  return (
    <div className="view-inner settings-page">
      <div className="view-head"><h2>设置</h2></div>
      <div className="settings-shell">
        <nav className="panel settings-nav" aria-label="设置目录">
          <button type="button" className={section === 'general' ? 'settings-nav-item active' : 'settings-nav-item'} onClick={() => setSection('general')}>通用</button>
          <button type="button" className={section === 'model' ? 'settings-nav-item active' : 'settings-nav-item'} onClick={() => setSection('model')}>模型与 API</button>
          <button type="button" className={section === 'embedding' ? 'settings-nav-item active' : 'settings-nav-item'} onClick={() => setSection('embedding')}>知识库 Embedding</button>
          <button type="button" className={section === 'tools' ? 'settings-nav-item active' : 'settings-nav-item'} onClick={() => setSection('tools')}>工具与扩展</button>
        </nav>
        <div className="settings-content">
          {section === 'general' && (
            <section className="panel settings-main">
              <div className="settings-section-head"><h3>通用</h3></div>
              <div className="settings-form">
                <dl className="settings-facts general-facts">
                  <div><dt>应用</dt><dd>ShadowFlow 工作台</dd></div>
                  <div><dt>运行环境</dt><dd>本地前后端联调</dd></div>
                </dl>
                <div className="settings-actions"><button type="button" className="btn btn-primary" onClick={() => setSection('model')}>管理模型与 API</button></div>
              </div>
            </section>
          )}
          {section === 'model' && (
            <section className="panel settings-main">
              <div className="settings-section-head">
                <h3>模型与 API</h3>
                <span className={hasKey ? 'settings-badge saved' : 'settings-badge'}>{hasKey ? '密钥已保存' : '未配置密钥'}</span>
              </div>
              <form className="settings-form" onSubmit={submit} noValidate autoComplete="off">
                <div className="settings-grid">
                  <div className="form-group">
                    <label className="form-label" htmlFor="settings-provider">服务提供商</label>
                    <select id="settings-provider" className="form-select" value="mimo" disabled>
                      <option value="mimo">MiMo</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="settings-model">模型</label>
                    <select id="settings-model" className="form-select" value={MIMO_MODEL} disabled>
                      <option value={MIMO_MODEL}>MiMo v2.6 Pro</option>
                    </select>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="settings-base-url">Base URL</label>
                  <input id="settings-base-url" className="form-input" value={MIMO_BASE_URL} readOnly />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="settings-api-key">API Key</label>
                  <div className="settings-key-row">
                    <input id="settings-api-key" className="form-input" type={showKey ? 'text' : 'password'} value={apiKey} onChange={event => { setApiKey(event.target.value); setConfirmClear(false); }} placeholder={hasKey ? '已有密钥；留空保存则保持不变' : '输入你的 MiMo API Key'} autoComplete="new-password" spellCheck={false} />
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShowKey(value => !value)}>{showKey ? '隐藏' : '显示'}</button>
                  </div>
                  <div className="settings-help">密钥不会回显；仅保存在当前浏览器 localStorage，未加密，请勿在共享设备上使用。</div>
                </div>
                <div className="settings-notice">保存配置不代表已验证连接，首次真实对话时会向 MiMo 发起请求。</div>
                {error && <div className="settings-feedback error" role="alert">{error}</div>}
                {feedback && <div className="settings-feedback" role="status">{feedback}</div>}
                <div className="settings-actions">
                  <button type="submit" className="btn btn-primary">保存配置</button>
                  <button type="button" className="btn btn-danger" disabled={!hasKey} onClick={clearKey}>{confirmClear ? '确认清除' : '清除密钥'}</button>
                  {confirmClear && <button type="button" className="btn btn-ghost" onClick={() => { setConfirmClear(false); setFeedback(''); }}>取消</button>}
                </div>
              </form>
            </section>
          )}
          {section === 'embedding' && (
            <section className="panel settings-main">
              <div className="settings-section-head">
                <h3>知识库 Embedding</h3>
                <span className={embedding.hasKey ? 'settings-badge saved' : 'settings-badge'}>{embedding.hasKey ? '密钥已保存' : '未配置密钥'}</span>
              </div>
              <div className="settings-form">
                <div className="settings-grid">
                  <div className="form-group">
                    <label className="form-label" htmlFor="embedding-provider">服务提供商</label>
                    <select id="embedding-provider" className="form-select" value={embedding.provider} onChange={event => selectEmbeddingProvider(event.target.value as EmbeddingProvider)}>
                      {Object.entries(EMBEDDING_PROVIDERS).map(([id, preset]) => <option key={id} value={id}>{preset.label}</option>)}
                      <option value="custom">自定义 OpenAI 兼容接口</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label" htmlFor="embedding-model">模型</label>
                    {embedding.provider === 'custom' ? (
                      <input id="embedding-model" className="form-input" value={embedding.model} onChange={event => setEmbedding(previous => ({ ...previous, model: event.target.value }))} placeholder="输入 Embedding 模型名称" />
                    ) : (
                      <select id="embedding-model" className="form-select" value={embedding.model} onChange={event => setEmbedding(previous => ({ ...previous, model: event.target.value }))}>
                        {EMBEDDING_PROVIDERS[embedding.provider].models.map(model => <option key={model} value={model}>{model}</option>)}
                      </select>
                    )}
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="embedding-base-url">Base URL</label>
                  <input id="embedding-base-url" className="form-input" value={embedding.baseUrl} readOnly={embedding.provider !== 'custom'} onChange={event => setEmbedding(previous => ({ ...previous, baseUrl: event.target.value }))} placeholder={DEFAULT_EMBEDDING.baseUrl} />
                </div>
                <div className="form-group">
                  <label className="form-label" htmlFor="embedding-key">API Key</label>
                  <input id="embedding-key" className="form-input" type="password" value={embeddingKey} onChange={event => setEmbeddingKey(event.target.value)} placeholder={embedding.hasKey ? '已有密钥；留空保存则保持不变' : '输入你的 Embedding API Key'} autoComplete="new-password" spellCheck={false} />
                  <div className="settings-help">仅保存在当前浏览器 localStorage；Node 只在本次请求内转发，Python 只在内存中创建向量客户端，不写入数据库。</div>
                </div>
                <div className="settings-notice">上传文件时会生成真实向量；对话与知识库搜索将使用向量与关键词混合检索。更换模型后请使用新的知识库，避免向量维度不一致。</div>
                {embeddingError && <div className="settings-feedback error" role="alert">{embeddingError}</div>}
                {embeddingFeedback && <div className="settings-feedback" role="status">{embeddingFeedback}</div>}
                <div className="settings-actions">
                  <button type="button" className="btn btn-primary" onClick={saveEmbedding}>保存配置</button>
                  <button type="button" className="btn btn-ghost" disabled={embeddingTesting} onClick={() => void testEmbedding()}>{embeddingTesting ? '正在测试…' : '测试连接'}</button>
                  <button type="button" className="btn btn-danger" disabled={!embedding.hasKey} onClick={() => { setEmbedding(clearEmbeddingKey()); setEmbeddingKey(''); setEmbeddingFeedback('Embedding 密钥已清除，知识库将回退到关键词检索。'); setEmbeddingError(''); }}>清除密钥</button>
                </div>
              </div>
            </section>
          )}
          {section === 'tools' && (
            <section className="panel settings-main">
              <div className="settings-section-head"><h3>工具与扩展</h3><span className={toolSettings.tavilyKey || toolSettings.serpapiKey ? 'settings-badge saved' : 'settings-badge'}>{toolSettings.tavilyKey || toolSettings.serpapiKey ? '搜索已配置' : '搜索未配置'}</span></div>
              <div className="settings-form">
                <div className="settings-notice">可用工具：Web Search、网页读取、本地只读文件、GitHub 读取、消息读取和图片生成。员工只会获得组织档案中明确授权的工具；Shell、写入、发布、邮件等高风险操作不会在此隐式开放。</div>
                <div className="form-group"><label className="form-label" htmlFor="tool-tavily">Tavily API Key（网页搜索，推荐）</label><input id="tool-tavily" className="form-input" type="password" value={toolSettings.tavilyKey} onChange={event => setToolSettings(previous => ({ ...previous, tavilyKey: event.target.value }))} autoComplete="new-password" /></div>
                <div className="form-group"><label className="form-label" htmlFor="tool-serpapi">SerpAPI Key（可选，优先于 Tavily）</label><input id="tool-serpapi" className="form-input" type="password" value={toolSettings.serpapiKey} onChange={event => setToolSettings(previous => ({ ...previous, serpapiKey: event.target.value }))} autoComplete="new-password" /></div>
                <div className="form-group"><label className="form-label" htmlFor="tool-github">GitHub Token（可选，用于 GitHub 读取）</label><input id="tool-github" className="form-input" type="password" value={toolSettings.githubToken} onChange={event => setToolSettings(previous => ({ ...previous, githubToken: event.target.value }))} autoComplete="new-password" /></div>
                <div className="settings-help">密钥仅保存在当前浏览器并随本次工具调用转发。未配置密钥时 Web Search 会用公开网页结果兜底（结果标注 provider: bing-html）；兜底抓不到时如实失败，不会伪造搜索结果。</div>
                {toolFeedback && <div className="settings-feedback" role="status">{toolFeedback}</div>}
                <div className="settings-actions"><button type="button" className="btn btn-primary" onClick={saveTools}>保存工具配置</button><button type="button" className="btn btn-danger" onClick={() => { const empty = { tavilyKey: '', serpapiKey: '', githubToken: '' }; saveToolSettings(empty); setToolSettings(empty); setToolFeedback('工具密钥已清除。'); }}>清除工具密钥</button></div>
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
