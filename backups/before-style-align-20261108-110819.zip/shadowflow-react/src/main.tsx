import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles.css';
import './modern.css';
import './approval-deliverable.css';
import './shop.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
