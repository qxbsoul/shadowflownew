import { randomUUID } from 'node:crypto';
import { callProvider, isProviderId, PROVIDERS_NO_KEY, type ProviderId } from '../transport/api-clients';
import { planWithLlm } from '../lib/orchestrator-parse';
import { describePlan, heuristicPlan, isCasualChat, type StrategyAgent } from '../lib/chat-strategy';
import { ThinkingDeltaParser, type OpcChatActivity, type OpcChatStreamEvent } from './opc-chat-stream';
import {
  appendOpcMessage,
  createOpcApproval,
  decideOpcApproval,
  getOpcApproval,
  getOpcConversation,
  listOpcMessages,
  renameOpcConversation,
  type OpcApprovalDecision,
  type OpcApprovalOutcome,
  type OpcChatApproval,
  type OpcChatMessage,
} from '../storage/opc-chat';
import { PYTHON_BACKEND_URL } from '../python-backend';
import { fetchMemoryBankHits, renderKnowledgeBlock } from '../lib/memory-bank';
import { listKnowledgePackIds } from '../storage/opc-knowledge';
import { recordUsage } from '../storage/token-usage';
import type { OpcChatAttachment } from './opc-attachments';

export class OpcChatError extends Error {
  constructor(public status: number, public code: string, message: string) {
    super(message);
  }
}

interface Employee {
  id: string;
  name: string;
  title?: string;
  role?: string;
  system_prompt?: string;
  skills?: string[];
  tools?: string[];
  status?: string;
  employment?: string;
}

export interface OpcChatModelConfig {
  provider: ProviderId;
  model?: string;
  apiKey?: string;
  baseUrl?: string;
  companyId?: string;
  sessionId?: string;
  attachments?: OpcChatAttachment[];
}

export interface OpcDagNodeMetadata {
  id: string;
  planner_task_id: string | null;
  agent_id: string;
  name: string;
  title: string;
  prompt: string;
  depends_on: string[];
  declared_depends_on: string[];
  requires_approval: boolean;
  validation_error: string | null;
}

export interface OpcChatTurnResult {
  messages: OpcChatMessage[];
  plan?: {
    strategy: string;
    source: string;
    assignments: Array<{ agent_id: string; name: string; title: string; depends_on: string[] }>;
    dag: { nodes: OpcDagNodeMetadata[] };
  };
}

async function pythonGet<T>(path: string, authorization: string): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const response = await fetch(`${PYTHON_BACKEND_URL}${path}`, {
      headers: { Authorization: authorization }, signal: ctrl.signal,
    });
    if (!response.ok) throw new OpcChatError(response.status, response.status === 401 ? 'UNAUTHORIZED' : 'COMPANY_API_ERROR', '账号或公司数据校验失败');
    return await response.json() as T;
  } catch (error) {
    if (error instanceof OpcChatError) throw error;
    throw new OpcChatError(503, 'PYTHON_BACKEND_UNAVAILABLE', '公司业务后端暂时不可用');
  } finally {
    clearTimeout(timer);
  }
}

export async function opcChatCompany(authorization: string): Promise<{ id: string; name: string }> {
  if (!authorization.startsWith('Bearer ')) throw new OpcChatError(401, 'UNAUTHORIZED', '请先登录');
  const body = await pythonGet<{ company: { id: string; name: string } }>('/api/opc/auth/me', authorization);
  return body.company;
}

async function complete(
  config: OpcChatModelConfig,
  systemPrompt: string,
  userMessage: string,
  callImpl: typeof callProvider,
  stream?: { clientId: string; emit: (event: OpcChatStreamEvent) => void },
  usageContext?: { companyId: string; sessionId: string },
): Promise<{ text: string; thinking: string; durationMs: number }> {
  const startedAt = Date.now();
  const parser = new ThinkingDeltaParser(stream?.clientId ?? '', stream?.emit);
  let failure: { code?: string; message: string } | null = null;
  for await (const chunk of callImpl(config.provider, {
    systemPrompt,
    userMessage,
    attachments: config.attachments?.filter((item): item is OpcChatAttachment & { kind: 'image' | 'video'; data_url: string } => (item.kind === 'image' || item.kind === 'video') && Boolean(item.data_url))
      .map(item => ({ kind: item.kind, data_url: item.data_url })),
    model: config.model,
    api_key: config.apiKey,
    base_url: config.baseUrl,
    max_tokens: 2600,
    temperature: 0.35,
  })) {
    if (chunk.type === 'text-delta') parser.push(chunk.text);
    if (chunk.type === 'usage' && (usageContext || config.companyId)) recordUsage({
      company_id: usageContext?.companyId ?? config.companyId!, session_id: usageContext?.sessionId ?? config.sessionId ?? '', model: config.model,
      input_tokens: chunk.usage.input_tokens, cached_input_tokens: chunk.usage.cache_read_input_tokens,
      output_tokens: chunk.usage.output_tokens,
    });
    if (chunk.type === 'error') {
      failure = { code: chunk.code, message: chunk.message };
      break;
    }
  }
  if (failure) {
    const status = failure.code === 'NO_API_KEY' ? 401 : failure.code === 'RATE_LIMITED' ? 429 : 502;
    throw new OpcChatError(status, failure.code ?? 'LLM_UPSTREAM_ERROR', failure.message);
  }
  const text = parser.finish();
  if (!text) throw new OpcChatError(502, 'LLM_EMPTY_RESPONSE', '模型没有返回有效内容');
  return { text, thinking: parser.thinking, durationMs: Math.max(0, Date.now() - startedAt) };
}

function transcript(messages: OpcChatMessage[]): string {
  return messages.slice(-24).map((message) => {
    const role = message.sender_kind === 'user' ? '老板' : message.sender_name;
    return `${role}：${message.content}`;
  }).join('\n').slice(-30_000);
}

interface DagNode extends OpcDagNodeMetadata {
  systemPrompt: string;
  preblocked: boolean;
}

type TaskResult = {
  status: 'done' | 'failed' | 'blocked' | 'rejected';
  message?: OpcChatMessage;
  handoff?: string;
};

const approvalWaiters = new Map<string, {
  resolve: (outcome: OpcApprovalOutcome) => void;
  emit?: (event: OpcChatStreamEvent) => void;
}>();

export function decideOpcChatApproval(input: {
  approvalId: string;
  conversationId: string;
  companyId: string;
  decision: OpcApprovalDecision;
  customText?: string;
  outcome?: OpcApprovalOutcome;
}): { approval: OpcChatApproval; message: OpcChatMessage } {
  const existing = getOpcApproval(input.approvalId, input.companyId);
  if (!existing || existing.conversation_id !== input.conversationId) {
    throw new OpcChatError(404, 'APPROVAL_NOT_FOUND', '审批记录不存在');
  }
  if (existing.status !== 'pending') {
    throw new OpcChatError(409, 'APPROVAL_ALREADY_DECIDED', '该审批已经提交过决定');
  }
  const customText = String(input.customText ?? '').trim();
  if (input.decision === 'custom' && !customText) {
    throw new OpcChatError(422, 'CUSTOM_DECISION_REQUIRED', '自定义决定必须填写内容');
  }
  if (customText.length > 4000) {
    throw new OpcChatError(413, 'CUSTOM_DECISION_TOO_LARGE', '自定义决定不能超过 4000 字');
  }
  const outcome = input.decision === 'approve' ? 'continue' : input.decision === 'reject' ? 'reject' : input.outcome;
  if (!outcome || !['continue', 'reject'].includes(outcome)) {
    throw new OpcChatError(422, 'APPROVAL_OUTCOME_REQUIRED', '自定义决定必须明确 continue 或 reject');
  }
  const approval = decideOpcApproval(input.approvalId, input.companyId, input.decision, customText, outcome);
  if (!approval) throw new OpcChatError(409, 'APPROVAL_ALREADY_DECIDED', '该审批已经提交过决定');
  const decisionLabel = input.decision === 'approve' ? '批准' : input.decision === 'reject' ? '驳回' : '自定义决定';
  const message = appendOpcMessage(existing.conversation_id, {
    sender_kind: 'user', sender_name: '老板', channel: 'workflow', run_id: existing.run_id,
    task_id: existing.task_id, task_title: existing.task_title,
    content: `${decisionLabel}《${existing.task_title}》：${outcome === 'continue' ? '继续执行' : '停止该任务及其下游'}${customText ? `\n${customText}` : ''}`,
    status: 'done', metadata: { approval },
  });
  const waiter = approvalWaiters.get(approval.id);
  approvalWaiters.delete(approval.id);
  waiter?.emit?.({ type: 'approval', approval });
  waiter?.resolve(outcome);
  return { approval, message };
}

function explicitApproval(title: string, prompt: string, declared: boolean | undefined): boolean {
  return declared === true || /待老板(?:确认|审批)|需(?:要)?老板(?:确认|审批)|老板(?:确认|审批)后|批准后(?:再|才)|确认后(?:再|才)/.test(`${title}\n${prompt}`);
}

export async function runOpcChatTurn(input: {
  conversationId: string;
  companyId: string;
  content: string;
  attachments?: OpcChatAttachment[];
  config: OpcChatModelConfig;
  authorization: string;
  embeddingHeaders?: Record<string, string>;
  callImpl?: typeof callProvider;
  onEvent?: (event: OpcChatStreamEvent) => void;
}): Promise<OpcChatTurnResult> {
  input.config.companyId = input.companyId;
  input.config.sessionId = input.conversationId;
  input.config.attachments = input.attachments ?? [];
  const content = input.content.trim() || (input.attachments?.length ? '请分析我发送的附件' : '');
  if (!content) throw new OpcChatError(422, 'EMPTY_MESSAGE', '请输入对话内容或添加附件');
  if (content.length > 12_000) throw new OpcChatError(413, 'MESSAGE_TOO_LARGE', '单条消息不能超过 12000 字');
  const conversation = getOpcConversation(input.conversationId, input.companyId);
  if (!conversation) throw new OpcChatError(404, 'CONVERSATION_NOT_FOUND', '对话不存在');
  if (!isProviderId(input.config.provider)) throw new OpcChatError(422, 'INVALID_PROVIDER', '模型提供商不受支持');
  if (!input.config.apiKey && !PROVIDERS_NO_KEY.has(input.config.provider)) {
    throw new OpcChatError(401, 'NO_API_KEY', '请先在设置中配置当前模型的 API Key');
  }
  const call = input.callImpl ?? callProvider;
  const runId = randomUUID();
  const previous = listOpcMessages(conversation.id);
  appendOpcMessage(conversation.id, { sender_kind: 'user', sender_name: '老板', content, run_id: runId,
    metadata: input.attachments?.length ? { attachments: input.attachments } : null });
  if (previous.length === 0) renameOpcConversation(conversation.id, content);

  const beginMessage = (
    senderKind: 'ceo' | 'agent', senderName: string, agentId?: string,
    channel: OpcChatMessage['channel'] = 'chat', task?: { id: string; title: string }, workflow = channel === 'workflow' || Boolean(task),
  ) => {
    const clientId = randomUUID();
    input.onEvent?.({
      type: 'message-start', client_id: clientId, sender_kind: senderKind, sender_name: senderName,
      agent_id: agentId, channel, run_id: runId, task_id: task?.id, task_title: task?.title, workflow,
    });
    return clientId;
  };
  const endMessage = (clientId: string, message: OpcChatMessage) => {
    input.onEvent?.({ type: 'message-end', client_id: clientId, message });
  };
  const activity = (
    id: string,
    patch: Partial<OpcChatActivity> & Pick<OpcChatActivity, 'kind' | 'name' | 'title' | 'status' | 'actor'>,
  ): OpcChatActivity => {
    const value: OpcChatActivity = { id, run_id: runId, created_at: new Date().toISOString(), ...patch };
    input.onEvent?.({ type: 'activity', activity: value });
    if (value.status !== 'running') {
      appendOpcMessage(conversation.id, {
        sender_kind: 'system', sender_name: value.actor, content: `${value.title}${value.detail ? `：${value.detail}` : ''}`,
        channel: 'workflow', run_id: runId, task_id: value.task_id, status: value.status,
        duration_ms: value.duration_ms, metadata: { activity: value },
      });
    }
    return value;
  };

  // 单聊是“老板只面对总经理”的沟通方式，不是总经理亲自包办任务。
  // 只有纯寒暄直接应答；咨询和任务都进入同一套员工编排与真实模型调用。
  if (conversation.kind === 'single' && isCasualChat(content)) {
    const clientId = beginMessage('ceo', '总经理');
    const result = await complete(input.config, [
      '你是 AI 营销公司的总经理，只负责理解老板意图、调度和经营沟通。',
      '寒暄时简洁回应；不得虚构已经执行的外部操作。',
    ].join('\n'), `以下是历史对话：\n${transcript(previous)}\n\n老板最新消息：${content}`, call,
    input.onEvent ? { clientId, emit: input.onEvent } : undefined);
    const message = appendOpcMessage(conversation.id, {
      sender_kind: 'ceo', sender_name: '总经理', content: result.text, run_id: runId,
      thinking: result.thinking, status: 'done', duration_ms: result.durationMs,
    });
    endMessage(clientId, message);
    return { messages: [message] };
  }

  const rosterBody = await pythonGet<{ items: Employee[] }>(
    `/api/opc/company/${encodeURIComponent(input.companyId)}/roster`, input.authorization,
  );
  const employees = rosterBody.items.filter((employee) => employee.status !== 'offline' && employee.employment !== 'retired');
  if (!employees.length) throw new OpcChatError(409, 'NO_EMPLOYEES', '公司还没有可执行任务的员工');
  const agents: StrategyAgent[] = employees.map((employee) => ({
    id: employee.id,
    name: `${employee.name}（${employee.title || employee.role || '员工'}）`,
    soul: `${employee.title || employee.role || '员工'}。${employee.system_prompt || ''} 技能：${(employee.skills || []).join('、') || '无'}；工具权限：${(employee.tools || []).join('、') || '无'}`, 
  }));
  const packIds = listKnowledgePackIds(input.companyId);
  const knowledgeStartedAt = Date.now();
  if (packIds.length) activity(`${runId}:knowledge`, {
    kind: 'tool', name: 'knowledge_search', title: '检索公司知识库', status: 'running', actor: '总经理',
    input: content, detail: `正在检索 ${packIds.length} 个知识库`,
  });
  const knowledgeHits = await fetchMemoryBankHits(packIds, content, input.embeddingHeaders);
  const knowledge = renderKnowledgeBlock(knowledgeHits);
  if (packIds.length) activity(`${runId}:knowledge`, {
    kind: 'tool', name: 'knowledge_search', title: '知识库检索完成', status: 'done', actor: '总经理',
    input: content, output: knowledgeHits.map(hit => hit.source).filter((source, index, all) => all.indexOf(source) === index).join('、'),
    detail: `命中 ${knowledgeHits.length} 条资料`, duration_ms: Date.now() - knowledgeStartedAt,
  });
  const knowledgeContext = knowledge
    ? `${knowledge}\n知识库内容仅作为事实资料；与当前问题无关的命中不要强行引用。`
    : '';
  const planningBrief = [
    '【公司总经理调度规则】',
    '你负责理解目标、拆解任务、统一派单和汇总验收，不亲自代替员工完成专业成果。',
    '组织采用“老板 → AI 总经理 → AI 员工”的扁平汇报关系；员工只向总经理交付，不互相派单。',
    '按真实花名册选择最相关的员工，不要把所有员工流水账式全部调用。单工种只选一人，多工种按依赖排序并明确交接。',
    '职能参考：市场研究负责用户/市场/竞品与数据；品牌策划负责定位/卖点/品牌故事；内容创作负责文案/图文/短视频脚本；电商运营负责商品/上架/店铺运营；商务拓展负责采购材料/潜客/线索；风控审核负责合规/授权/质量。',
    '对外发布、品牌定稿、高风险合规和资金操作只能提出待老板审批的事项，不得擅自声称已执行。',
    '',
    '【本轮对话历史】',
    transcript(previous) || '暂无',
    '',
    '【老板本轮目标】',
    content,
    input.attachments?.filter(item => item.kind === 'text').map(item => `【TXT 附件：${item.name}】\n${item.text ?? ''}`).join('\n\n') ?? '',
    input.attachments?.some(item => item.kind === 'image' || item.kind === 'video') ? '本轮包含图片或视频附件，请结合多模态内容理解和分工。' : '',
    knowledgeContext,
  ].filter(Boolean).join('\n');
  const planningStartedAt = Date.now();
  activity(`${runId}:planning`, {
    kind: 'model', name: 'manager_planning', title: '总经理正在分析目标与分工', status: 'running', actor: '总经理',
    detail: '结合对话、知识资料与员工能力制定 DAG 执行计划',
  });
  const plan = await planWithLlm({
    userText: planningBrief,
    agents,
    provider: input.config.provider,
    apiKey: input.config.apiKey,
    model: input.config.model,
    baseUrl: input.config.baseUrl,
    attachments: input.config.attachments?.filter((item): item is OpcChatAttachment & { kind: 'image' | 'video'; data_url: string } => (item.kind === 'image' || item.kind === 'video') && Boolean(item.data_url))
      .map(item => ({ kind: item.kind, data_url: item.data_url })),
    callImpl: call,
    onUsage: usage => recordUsage({
      company_id: input.companyId, session_id: input.conversationId, model: input.config.model,
      input_tokens: usage.input_tokens, cached_input_tokens: usage.cache_read_input_tokens, output_tokens: usage.output_tokens,
    }),
    onThinkingDelta: (_delta, thinking) => activity(`${runId}:planning`, {
      kind: 'model', name: 'manager_planning', title: '总经理正在分析目标与分工', status: 'running', actor: '总经理',
      thinking, detail: '结合对话、知识资料与员工能力制定 DAG 执行计划',
    }),
  }) ?? heuristicPlan(content, agents);
  const byId = new Map(employees.map((employee) => [employee.id, employee]));
  const nameOf = (id: string) => agents.find((agent) => agent.id === id)?.name ?? id;
  const executionChannel: OpcChatMessage['channel'] = conversation.kind === 'single' ? 'workflow' : 'chat';

  const nodes: DagNode[] = plan.tasks.map((task, index) => {
    const employee = byId.get(task.agentId);
    return {
      id: `${runId}:task:${index + 1}`,
      planner_task_id: task.id ?? null,
      agent_id: task.agentId,
      name: nameOf(task.agentId),
      title: task.title,
      prompt: task.prompt,
      depends_on: [],
      declared_depends_on: task.depends_on ?? [],
      requires_approval: explicitApproval(task.title, task.prompt, task.requires_approval),
      validation_error: employee ? null : `执行员工不存在：${task.agentId}`,
      systemPrompt: [
        employee?.system_prompt || `你是公司的${employee?.title || employee?.role || '员工'}${employee?.name || ''}，只负责自己的专业工单。`,
        `你的岗位是${employee?.title || employee?.role || '员工'}，你只执行总经理派发且属于本岗位的任务，并向总经理汇报。`,
        `你的技能：${(employee?.skills || []).join('、') || '未配置'}。允许使用的工具权限：${(employee?.tools || []).join('、') || '无'}；不得声称使用未授权工具。`,
      ].join('\n'),
      preblocked: !employee,
    };
  });
  const byPlannerId = new Map(nodes.filter(node => node.planner_task_id).map(node => [node.planner_task_id as string, node]));
  const byAgentId = new Map(nodes.map(node => [node.agent_id, node]));
  const byRuntimeId = new Map(nodes.map(node => [node.id, node]));
  for (const node of nodes) {
    for (const ref of node.declared_depends_on) {
      const upstream = byPlannerId.get(ref) ?? byRuntimeId.get(ref) ?? byAgentId.get(ref);
      if (!upstream) {
        node.validation_error = `缺失依赖：${ref}`;
        node.preblocked = true;
      } else {
        node.depends_on.push(upstream.id);
      }
    }
  }

  // Mark only actual cycle members. Other valid branches remain executable.
  const visitState = new Map<string, 'visiting' | 'visited'>();
  const visitStack: DagNode[] = [];
  const detectCycle = (node: DagNode): void => {
    if (node.preblocked || visitState.get(node.id) === 'visited') return;
    if (visitState.get(node.id) === 'visiting') {
      const start = visitStack.findIndex(item => item.id === node.id);
      for (const cyclic of visitStack.slice(start)) {
        cyclic.validation_error = '依赖关系存在循环';
        cyclic.preblocked = true;
      }
      return;
    }
    visitState.set(node.id, 'visiting');
    visitStack.push(node);
    for (const dependency of node.depends_on) {
      const upstream = byRuntimeId.get(dependency);
      if (upstream) detectCycle(upstream);
    }
    visitStack.pop();
    visitState.set(node.id, 'visited');
  };
  for (const node of nodes) detectCycle(node);

  const dag = {
    nodes: nodes.map(node => ({
      id: node.id,
      planner_task_id: node.planner_task_id,
      agent_id: node.agent_id,
      name: node.name,
      title: node.title,
      prompt: node.prompt,
      depends_on: node.depends_on,
      declared_depends_on: node.declared_depends_on,
      requires_approval: node.requires_approval,
      validation_error: node.validation_error,
    })),
  };
  const planClientId = beginMessage('ceo', '总经理', undefined, executionChannel, undefined, true);
  const planText = `${describePlan(plan, nameOf)}\n${plan.tasks.map((task, index) => `${index + 1}. ${nameOf(task.agentId)}：${task.title}`).join('\n')}`;
  activity(`${runId}:planning`, {
    kind: 'model', name: 'manager_planning', title: '总经理已完成 DAG 分工', status: 'done', actor: '总经理',
    output: planText, thinking: plan.thinking, detail: `${plan.tasks.length} 个岗位工单，独立分支并行、依赖分支交接`, duration_ms: Date.now() - planningStartedAt,
  });
  input.onEvent?.({ type: 'content-delta', client_id: planClientId, text: planText });
  const planMessage = appendOpcMessage(conversation.id, {
    sender_kind: 'ceo', sender_name: '总经理', content: planText, channel: executionChannel,
    run_id: runId, thinking: plan.thinking ?? '', status: 'done', metadata: {
      strategy: plan.strategy,
      source: plan.source,
      assignments: nodes.map(node => ({ agent_id: node.agent_id, name: node.name, title: node.title, depends_on: node.depends_on })),
      dag,
    },
  });
  endMessage(planClientId, planMessage);

  // Every node is visible before any model execution starts.
  for (const node of nodes) {
    activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
      kind: 'model', name: 'employee_task', title: node.title, status: 'pending', actor: node.name,
      agent_id: node.agent_id, task_id: node.id, depends_on: node.depends_on,
      input: node.prompt, detail: node.validation_error ?? (node.depends_on.length ? '等待声明的上游任务' : '等待并行调度'),
    });
  }
  for (const node of nodes.filter(item => item.preblocked)) {
    activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
      kind: 'model', name: 'employee_task', title: node.title, status: 'blocked', actor: node.name,
      agent_id: node.agent_id, task_id: node.id, depends_on: node.depends_on,
      detail: node.validation_error ?? '依赖校验失败',
    });
  }

  const results = new Map<string, Promise<TaskResult>>();
  const executeNode = (node: DagNode): Promise<TaskResult> => {
    const promise = (async (): Promise<TaskResult> => {
      if (node.preblocked) return { status: 'blocked' };
      const upstreamResults = await Promise.all(node.depends_on.map(id => results.get(id) as Promise<TaskResult>));
      const failedUpstream = upstreamResults.findIndex(result => result.status !== 'done');
      if (failedUpstream >= 0) {
        const upstreamId = node.depends_on[failedUpstream];
        const detail = `上游任务未完成，已阻断：${upstreamId}`;
        activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
          kind: 'model', name: 'employee_task', title: node.title, status: 'blocked', actor: node.name,
          agent_id: node.agent_id, task_id: node.id, depends_on: node.depends_on, detail,
        });
        return { status: 'blocked' };
      }

      if (node.requires_approval) {
        const approval = createOpcApproval({
          company_id: input.companyId, conversation_id: conversation.id, run_id: runId,
          task_id: node.id, task_title: node.title,
        });
        activity(`${runId}:approval:${node.id.split(':').at(-1)}`, {
          kind: 'approval', name: 'approval_required', title: `待老板审批：${node.title}`, status: 'waiting_approval', actor: '总经理',
          agent_id: node.agent_id, task_id: node.id, depends_on: node.depends_on, approval_id: approval.id,
          detail: '批准或选择继续后执行；驳回后停止本任务及其下游',
        });
        const approvalClientId = beginMessage('ceo', '总经理', undefined, 'workflow', { id: node.id, title: node.title });
        const approvalText = `《${node.title}》需要老板确认后才能执行。请批准、驳回，或填写自定义决定并明确是否继续。`;
        input.onEvent?.({ type: 'content-delta', client_id: approvalClientId, text: approvalText });
        const approvalMessage = appendOpcMessage(conversation.id, {
          sender_kind: 'ceo', sender_name: '总经理', content: approvalText, channel: 'workflow', run_id: runId,
          task_id: node.id, task_title: node.title, status: 'waiting_approval', metadata: { approval },
        });
        endMessage(approvalClientId, approvalMessage);
        const outcomePromise = new Promise<OpcApprovalOutcome>(resolve => {
          approvalWaiters.set(approval.id, { resolve, emit: input.onEvent });
        });
        input.onEvent?.({ type: 'approval', approval });
        const outcome = await outcomePromise;
        activity(`${runId}:approval:${node.id.split(':').at(-1)}`, {
          kind: 'approval', name: 'approval_decided', title: `老板已决定：${node.title}`, status: outcome === 'continue' ? 'done' : 'rejected', actor: '老板',
          agent_id: node.agent_id, task_id: node.id, depends_on: node.depends_on, approval_id: approval.id,
          detail: outcome === 'continue' ? '继续执行任务' : '停止本任务及其下游',
        });
        if (outcome === 'reject') return { status: 'rejected' };
      }

      const employee = byId.get(node.agent_id) as Employee;
      activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
        kind: 'model', name: 'employee_task', title: node.title, status: 'running', actor: employee.name,
        agent_id: employee.id, task_id: node.id, depends_on: node.depends_on,
      });
      activity(`${runId}:dispatch:${node.id.split(':').at(-1)}`, {
        kind: 'dispatch', name: 'employee_dispatch', title: `总经理 → ${employee.name}`, status: 'done', actor: '总经理',
        agent_id: employee.id, task_id: node.id, depends_on: node.depends_on, input: node.title,
        detail: node.depends_on.length ? '已派发工单，仅交接声明上游的成果' : '已派发独立岗位工单，并行执行',
      });
      const handoff = node.depends_on.map((dependency, index) => upstreamResults[index].handoff).filter(Boolean).join('\n\n');
      const prompt = [
        `公司对话历史：\n${transcript(previous)}`,
        `老板本轮目标：${content}`,
        `总经理通过任务工单分配给你的工作：${node.title}\n${node.prompt}`,
        knowledgeContext,
        handoff ? `上游员工向总经理回传、现由总经理交接给你的成果（仅限声明依赖）：\n${handoff.slice(-16_000)}` : '',
        '你是执行层员工，只向总经理提交本岗位成果，不向其他员工派单，也不直接代替老板作决策。',
        '请直接产出可验收的岗位成果。若使用了上游成果，必须实际衔接其内容，不要复述调度过程。',
        '缺少真实数据时明确列出缺口和可用假设，不得编造数据、来源、外部操作或审批结果。',
      ].filter(Boolean).join('\n\n');
      const clientId = beginMessage('agent', employee.name, employee.id, executionChannel, { id: node.id, title: node.title });
      const startedAt = Date.now();
      try {
        const result = await complete(
          input.config, node.systemPrompt, prompt, call,
          input.onEvent ? { clientId, emit: input.onEvent } : undefined,
        );
        const message = appendOpcMessage(conversation.id, {
          sender_kind: 'agent', sender_name: employee.name, agent_id: employee.id, content: result.text,
          channel: executionChannel, run_id: runId, task_id: node.id, task_title: node.title,
          thinking: result.thinking, status: 'done', duration_ms: result.durationMs,
          metadata: { depends_on: node.depends_on },
        });
        endMessage(clientId, message);
        activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
          kind: 'model', name: 'employee_task', title: node.title, status: 'done', actor: employee.name,
          agent_id: employee.id, task_id: node.id, depends_on: node.depends_on,
          output: result.text, thinking: result.thinking, duration_ms: Date.now() - startedAt,
        });
        return {
          status: 'done', message,
          handoff: `${employee.name}（${employee.title || '员工'}）交付《${node.title}》：\n${result.text}`,
        };
      } catch (error) {
        const detail = error instanceof Error ? error.message : String(error);
        const message = appendOpcMessage(conversation.id, {
          sender_kind: 'agent', sender_name: employee.name, agent_id: employee.id,
          content: detail, channel: 'workflow', run_id: runId,
          task_id: node.id, task_title: node.title, status: 'failed', metadata: { depends_on: node.depends_on },
        });
        endMessage(clientId, message);
        activity(`${runId}:task:${node.id.split(':').at(-1)}`, {
          kind: 'model', name: 'employee_task', title: node.title, status: 'failed', actor: employee.name,
          agent_id: employee.id, task_id: node.id, depends_on: node.depends_on, detail,
        });
        return { status: 'failed', message };
      }
    })();
    results.set(node.id, promise);
    return promise;
  };

  // Register promises synchronously in DAG plan order so dependents can always
  // find their upstream promise; actual independent model calls overlap.
  const taskPromises = nodes.map(node => executeNode(node));
  const settled = await Promise.all(taskPromises);
  const produced: OpcChatMessage[] = [planMessage];
  const handoffs: string[] = [];
  for (const result of settled) {
    if (result.message) produced.push(result.message);
    if (result.handoff) handoffs.push(result.handoff);
  }

  if (handoffs.length) {
    const summaryStartedAt = Date.now();
    activity(`${runId}:summary`, {
      kind: 'model', name: 'manager_summary', title: '总经理正在汇总员工成果', status: 'running', actor: '总经理',
      detail: `${handoffs.length} 个成功交付，${settled.filter(result => result.status !== 'done').length} 个未执行或失败节点`,
    });
    const summaryClientId = beginMessage('ceo', '总经理');
    const summary = await complete(input.config, [
      '你是 AI 营销公司的总经理，负责汇总员工回传的成果并对老板交付，不是执行员工。',
      '基于给定成果提炼最终决定、核心交付、数据缺口和下一步；不得添加员工没有提供的数字、事实或外部执行结果。',
      '涉及对外发布、高风险合规、品牌定稿或资金操作时，明确标记“待老板审批”，不得擅自批准。',
    ].join('\n'), [
      `老板目标：${content}`,
      `你的派单：\n${planText}`,
      `员工实际回传：\n${handoffs.join('\n\n').slice(-24_000)}`,
      `未成功节点：\n${settled.map((result, index) => result.status === 'done' ? '' : `${nodes[index].title}：${result.status}`).filter(Boolean).join('\n') || '无'}`,
      knowledgeContext,
      '请向老板汇总最终结果，避免重复整段粘贴员工原文；采用知识库事实时保留来源名称。',
    ].join('\n\n'), call, input.onEvent ? { clientId: summaryClientId, emit: input.onEvent } : undefined);
    const summaryMessage = appendOpcMessage(conversation.id, {
      sender_kind: 'ceo', sender_name: '总经理', content: summary.text, run_id: runId,
      thinking: summary.thinking, status: 'done', duration_ms: summary.durationMs,
    });
    endMessage(summaryClientId, summaryMessage);
    activity(`${runId}:summary`, {
      kind: 'model', name: 'manager_summary', title: '总经理已完成汇总', status: 'done', actor: '总经理',
      output: summary.text, thinking: summary.thinking, duration_ms: Date.now() - summaryStartedAt,
    });
    produced.push(summaryMessage);
  }

  return {
    messages: produced,
    plan: {
      strategy: plan.strategy,
      source: plan.source,
      assignments: nodes.map(node => ({ agent_id: node.agent_id, name: node.name, title: node.title, depends_on: node.depends_on })),
      dag,
    },
  };
}
