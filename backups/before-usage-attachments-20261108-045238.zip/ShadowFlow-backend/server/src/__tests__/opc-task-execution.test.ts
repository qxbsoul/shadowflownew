import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import express from 'express';
import request from 'supertest';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const { callProviderMock } = vi.hoisted(() => ({ callProviderMock: vi.fn() }));
vi.mock('../transport/api-clients', async (importOriginal) => ({
  ...await importOriginal<typeof import('../transport/api-clients')>(),
  callProvider: callProviderMock,
}));

import opcTaskExecutionRouter from '../routes/opc-task-execution';
import { _resetForTests } from '../storage/sqlite';

const app = express();
app.use(express.json());
app.use('/api/opc-internal', opcTaskExecutionRouter);

const originalCwd = process.cwd();
let dir = '';
const body = {
  company_id: 'co1',
  provider: 'mimo',
  model: 'mimo-v2.6-pro',
  system: '你是文案',
  user: '写一句真实文案',
};

beforeEach(() => {
  dir = mkdtempSync(join(tmpdir(), 'sf-opc-task-execution-'));
  process.chdir(dir);
  _resetForTests();
  delete process.env.MIMO_API_KEY;
  vi.clearAllMocks();
  callProviderMock.mockImplementation(async function* () {
    yield { type: 'text-delta', text: '<sf:thinking>先理解需求</sf:thinking>' };
    yield { type: 'text-delta', text: '真实模型交付' };
    yield { type: 'usage', usage: { input_tokens: 21, output_tokens: 8 } };
    yield { type: 'end' };
  });
  vi.stubGlobal('fetch', vi.fn(async (_input: string | URL | Request, init?: RequestInit) => {
    const authorization = new Headers(init?.headers).get('authorization');
    if (authorization !== 'Bearer co1') {
      return Response.json({ error: 'unauthorized' }, { status: 401 });
    }
    return Response.json({ company: { id: 'co1', name: '公司一' } });
  }));
});

afterEach(() => {
  vi.unstubAllGlobals();
  _resetForTests();
  process.chdir(originalCwd);
  rmSync(dir, { recursive: true, force: true });
});

describe('POST /api/opc-internal/tasks/complete', () => {
  it('映射真实 text/thinking/live/model/usage，并转发专用模型密钥头', async () => {
    const res = await request(app)
      .post('/api/opc-internal/tasks/complete')
      .set('Authorization', 'Bearer co1')
      .set('X-MiMo-Key', 'sk-mimo-task')
      .send(body)
      .expect(200);

    expect(res.body).toEqual({
      text: '真实模型交付',
      thinking: '先理解需求',
      mode: 'live',
      model: 'mimo-v2.6-pro',
      usage: { input_tokens: 21, output_tokens: 8 },
    });
    expect(callProviderMock).toHaveBeenCalledOnce();
    const [provider, input] = callProviderMock.mock.calls[0];
    expect(provider).toBe('mimo');
    expect(input).toMatchObject({
      systemPrompt: body.system,
      userMessage: body.user,
      model: body.model,
      api_key: 'sk-mimo-task',
    });
    expect(input.api_key).not.toBe('co1');
  });

  it('拒绝跨公司执行，且不调用模型', async () => {
    const res = await request(app)
      .post('/api/opc-internal/tasks/complete')
      .set('Authorization', 'Bearer co1')
      .set('X-MiMo-Key', 'sk-mimo-task')
      .send({ ...body, company_id: 'co2' })
      .expect(403);

    expect(res.body.error.code).toBe('COMPANY_MISMATCH');
    expect(callProviderMock).not.toHaveBeenCalled();
  });

  it('公司 Authorization 不会冒充模型 key，无 key 直接失败', async () => {
    const res = await request(app)
      .post('/api/opc-internal/tasks/complete')
      .set('Authorization', 'Bearer co1')
      .send(body)
      .expect(401);

    expect(res.body.error.code).toBe('NO_API_KEY');
    expect(callProviderMock).not.toHaveBeenCalled();
    expect(JSON.stringify(res.body)).not.toContain('simulated');
  });

  it('模型错误和空输出均 fail closed，不返回 simulated 结果', async () => {
    callProviderMock.mockImplementationOnce(async function* () {
      yield { type: 'error', code: 'PROVIDER_ERROR', message: 'upstream down' };
    });
    const failed = await request(app)
      .post('/api/opc-internal/tasks/complete')
      .set('Authorization', 'Bearer co1')
      .set('X-MiMo-Key', 'sk-mimo-task')
      .send(body)
      .expect(502);
    expect(failed.body.error.code).toBe('PROVIDER_ERROR');

    callProviderMock.mockImplementationOnce(async function* () {
      yield { type: 'text-delta', text: '<sf:thinking>只有思考</sf:thinking>' };
      yield { type: 'end' };
    });
    const empty = await request(app)
      .post('/api/opc-internal/tasks/complete')
      .set('Authorization', 'Bearer co1')
      .set('X-MiMo-Key', 'sk-mimo-task')
      .send(body)
      .expect(502);
    expect(empty.body.error.code).toBe('LLM_EMPTY_RESPONSE');
    expect(JSON.stringify({ failed: failed.body, empty: empty.body })).not.toContain('simulated');
  });
});
