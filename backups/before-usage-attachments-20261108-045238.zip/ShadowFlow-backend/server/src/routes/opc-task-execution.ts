import { Router, type Response } from 'express';
import { callProvider, isProviderId, PROVIDERS_NO_KEY, type ProviderChunk } from '../transport/api-clients';
import { resolveProviderBaseUrl, resolveProviderKey } from '../transport/byokKey';
import { opcChatCompany, OpcChatError } from '../services/opc-chat';
import { ThinkingDeltaParser } from '../services/opc-chat-stream';
import type { TokenUsage } from '../lib/conversation-types';

const router = Router();

function fail(res: Response, error: unknown): void {
  const err = error instanceof OpcChatError
    ? error
    : new OpcChatError(500, 'TASK_EXECUTION_INTERNAL', error instanceof Error ? error.message : String(error));
  res.status(err.status).json({ error: { code: err.code, message: err.message } });
}

/**
 * Python 公司状态机的唯一模型出口。这里只做公司鉴权和真实模型补全，
 * 不创建/修改项目、任务、审批或账本。
 */
router.post('/tasks/complete', (req, res) => {
  void (async () => {
    const authorization = req.headers.authorization || '';
    const company = await opcChatCompany(authorization);
    const companyId = String(req.body?.company_id || '').trim();
    if (!companyId || companyId !== company.id) {
      throw new OpcChatError(403, 'COMPANY_MISMATCH', '任务公司归属与登录公司不一致');
    }

    const provider = String(req.body?.provider || '');
    const model = String(req.body?.model || '').trim();
    const systemPrompt = String(req.body?.system || '');
    const userMessage = String(req.body?.user || '').trim();
    if (!isProviderId(provider) || !model || !userMessage) {
      throw new OpcChatError(422, 'INVALID_TASK_COMPLETION', 'provider、model 和 user 必须有效');
    }
    const apiKey = resolveProviderKey(provider, req.headers);
    if (!apiKey && !PROVIDERS_NO_KEY.has(provider)) {
      throw new OpcChatError(401, 'NO_API_KEY', '请先在设置中配置当前模型的 API Key');
    }

    const parser = new ThinkingDeltaParser('opc-task');
    const usage: TokenUsage = {};
    let failure: Extract<ProviderChunk, { type: 'error' }> | undefined;
    for await (const chunk of callProvider(provider, {
      systemPrompt,
      userMessage,
      model,
      api_key: apiKey,
      base_url: resolveProviderBaseUrl(provider),
      max_tokens: 4096,
      temperature: 0.2,
    })) {
      if (chunk.type === 'text-delta') parser.push(chunk.text);
      if (chunk.type === 'usage') Object.assign(usage, chunk.usage);
      if (chunk.type === 'error') {
        failure = chunk;
        break;
      }
    }
    if (failure) {
      const status = failure.code === 'NO_API_KEY' ? 401 : failure.code === 'RATE_LIMITED' ? 429 : 502;
      throw new OpcChatError(status, failure.code ?? 'LLM_UPSTREAM_ERROR', failure.message);
    }
    const text = parser.finish();
    if (!text) throw new OpcChatError(502, 'LLM_EMPTY_RESPONSE', '模型没有返回有效内容');

    res.json({ text, thinking: parser.thinking, mode: 'live', model, usage });
  })().catch((error) => fail(res, error));
});

export default router;
