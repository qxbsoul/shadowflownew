import { useEffect, useRef, useState } from 'react';
import { useWorkbench } from '../store';
import LiveBoard from './LiveBoard';
import ConversationSidebar from './ConversationSidebar';
import ChatRichContent from './ChatRichContent';
import ChatApprovalCard from './ChatApprovalCard';

const QUICK_CHIPS = [
  { label: '生成本周获客简报', text: '生成本周获客简报' },
  { label: '安排每日行业简报', text: '安排每天早上 9 点的行业简报' },
  { label: '复盘上周转化', text: '复盘上周的转化数据' },
  { label: '整理客户跟进计划', text: '整理本周客户跟进计划' },
];

export default function WorkbenchView() {
  const { messages, typing, sendChat, conversations, activeConversationId, openModal } = useWorkbench();
  const [text, setText] = useState('');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [expandedThinking, setExpandedThinking] = useState<Set<string>>(new Set());
  const [showJumpToLatest, setShowJumpToLatest] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);
  const stickToBottomRef = useRef(true);
  const activeConversation = conversations.find(item => item.id === activeConversationId);
  const projectLocked = Boolean(activeConversation?.projectId);
  const isGroup = activeConversation?.kind === 'group';

  useEffect(() => {
    const el = bodyRef.current;
    if (el && stickToBottomRef.current) el.scrollTop = el.scrollHeight;
  }, [messages, typing]);

  useEffect(() => {
    stickToBottomRef.current = true;
    setShowJumpToLatest(false);
  }, [activeConversationId]);

  useEffect(() => {
    if (!typing) {
      setElapsedSeconds(0);
      return;
    }
    const startedAt = Date.now();
    setElapsedSeconds(0);
    const timer = window.setInterval(() => setElapsedSeconds(Math.floor((Date.now() - startedAt) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [typing]);

  const sendAndFollow = (value: string) => {
    stickToBottomRef.current = true;
    setShowJumpToLatest(false);
    sendChat(value);
  };
  const send = () => {
    const value = text.trim();
    if (!value || typing) return;
    setText('');
    sendAndFollow(value);
  };
  const jumpToLatest = () => {
    const el = bodyRef.current;
    if (!el) return;
    stickToBottomRef.current = true;
    el.scrollTop = el.scrollHeight;
    setShowJumpToLatest(false);
  };
  const handleChatScroll = () => {
    const el = bodyRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    stickToBottomRef.current = distance < 80;
    setShowJumpToLatest(distance > 120);
  };

  const toggleThinking = (id: string) => {
    setExpandedThinking(previous => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="workbench">
      <ConversationSidebar collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(value => !value)} />
      <div className="chat-col">
        <div className="chat-head">
          <div className="ava">{isGroup ? '群' : '总'}</div>
          <div className="name">{isGroup ? '公司总经理群' : '总经理'}</div>
          <button className="btn btn-ghost btn-sm new-project-entry" onClick={() => openModal({ kind: 'new-project' })}>新建项目</button>
          <div className="model-chip" aria-label="当前模型">
            <span>模型</span>
            <strong>MiMo v2.6 Pro</strong>
          </div>
        </div>

        <div className="chat-scroll-wrap">
          <div className="chat-body" ref={bodyRef} onScroll={handleChatScroll}>
            {messages.map((m, i) => {
              const messageId = m.id ?? `message-${i}`;
              const showThinking = Boolean(m.thinking) && (!m.thinkingDone || expandedThinking.has(messageId));
              if (m.approval) return <ChatApprovalCard key={messageId} approval={m.approval} />;
              if (m.activity) {
                const activity = m.activity;
                const stateText = { pending: '等待上游', waiting_approval: '等待老板', running: '执行中', done: '完成', failed: '失败', blocked: '已阻塞', rejected: '已驳回' }[activity.status];
                return (
                  <div key={messageId} className={`chat-activity ${activity.kind} ${activity.status}`}>
                    <div className="chat-activity-marker" aria-hidden="true">{activity.kind === 'tool' ? '⌕' : activity.kind === 'dispatch' ? '→' : activity.kind === 'approval' ? '✓' : '◇'}</div>
                    <div className="chat-activity-body">
                      <div className="chat-activity-head"><strong>{activity.title}</strong><span>{stateText}{activity.duration_ms !== undefined ? ` · ${Math.max(1, Math.round(activity.duration_ms / 1000))} 秒` : ''}</span></div>
                      {activity.detail && <div className="chat-activity-detail">{activity.detail}</div>}
                      {activity.input && activity.kind === 'tool' && <div className="chat-activity-query">查询：{activity.input}</div>}
                      {activity.thinking && (
                        <details className="chat-activity-thinking" open={activity.status === 'running'}>
                          <summary>总经理思考过程</summary><div>{activity.thinking}</div>
                        </details>
                      )}
                      {activity.output && <details className="chat-activity-output"><summary>查看{activity.kind === 'model' ? '分工' : '结果'}</summary><ChatRichContent content={activity.output} /></details>}
                    </div>
                  </div>
                );
              }
              return (
                <div key={messageId} className={m.from === 'boss' ? 'msg-row boss' : `msg-row ${m.from}`}>
                  {m.from !== 'boss' && <div className="msg-ava">{m.from === 'ceo' ? '总' : m.from === 'agent' ? (m.senderName ?? '员').slice(0, 1) : '·'}</div>}
                  <div>
                    {m.from !== 'boss' && <div className="msg-sender">{m.senderName ?? (m.from === 'ceo' ? '总经理' : '系统')}</div>}
                    <div className="bubble">
                      {m.thinking && (
                        <div className={m.thinkingDone ? 'reasoning-block done' : 'reasoning-block'}>
                          <button type="button" className="reasoning-toggle" onClick={() => toggleThinking(messageId)} aria-expanded={showThinking}>
                            <span>{m.thinkingDone ? '思考过程' : '正在思考'}</span>
                            <span className={showThinking ? 'reasoning-chevron open' : 'reasoning-chevron'} aria-hidden="true">⌄</span>
                          </button>
                          {showThinking && <div className="reasoning-content">{m.thinking}</div>}
                        </div>
                      )}
                      <ChatRichContent content={m.text} className="answer-content" />
                      {m.card && (
                        <div className="biz-card">
                          <div className="bc-head">交付物</div>
                          <div className="bc-body">
                            <div className="bc-title">{m.card.title}</div>
                            <div className="bc-meta">{m.card.meta}</div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="msg-time">{m.time}</div>
                  </div>
                </div>
              );
            })}
            {typing && (
              <div className="thinking-elapsed" role="status" aria-live="polite">
                <span className="thinking-pulse" aria-hidden="true" />
                已思考 {elapsedSeconds} 秒
              </div>
            )}
          </div>
          {showJumpToLatest && (
            <button type="button" className="jump-latest" onClick={jumpToLatest} aria-label="回到最新对话" title="回到最新对话">
              <svg viewBox="0 0 20 20" width="20" height="20" aria-hidden="true"><path d="M10 3v12M5 10l5 5 5-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="square" /></svg>
            </button>
          )}
        </div>

        <div className="chat-foot">
          <div className="quick-chips">
            {QUICK_CHIPS.map(c => <button key={c.label} className="chip" disabled={typing || projectLocked} onClick={() => sendAndFollow(c.text)}>{c.label}</button>)}
          </div>
          {projectLocked && <div className="project-locked">此对话已绑定项目；有新需求请点击“新开对话”。</div>}
          <div className="input-row">
            <textarea
              className="chat-input"
              rows={1}
              placeholder={projectLocked ? '此对话已绑定项目，请新开对话创建新项目' : '给总经理派活，比如：整理上周获客数据，明早发我简报'}
              value={text}
              disabled={projectLocked}
              onChange={e => setText(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <button className="send-btn" onClick={send} disabled={typing || projectLocked || !text.trim()} title="发送">发送</button>
          </div>
        </div>
      </div>
      <LiveBoard />
    </div>
  );
}
