/* ShadowFlow · 公司化工作台类型定义。 */

export type ViewKey =
  | 'workbench'
  | 'orders'
  | 'approvals'
  | 'logs'
  | 'org'
  | 'tasks'
  | 'deliverables'
  | 'dashboard'
  | 'knowledge'
  | 'settings';

export interface MsgCard {
  kind: 'deliverable';
  title: string;
  meta: string;
}

export type ChatActivityStatus = 'pending' | 'waiting_approval' | 'running' | 'done' | 'failed' | 'blocked' | 'rejected';

export interface ChatApproval {
  id: string;
  company_id: string;
  conversation_id: string;
  run_id: string;
  task_id: string;
  task_title: string;
  status: 'pending' | 'decided';
  decision: 'approve' | 'reject' | 'custom' | null;
  custom_text: string;
  outcome: 'continue' | 'reject' | null;
  created_at: string;
  decided_at: string | null;
}

export interface ChatDagNode {
  id: string;
  planner_task_id?: string | null;
  agent_id: string;
  name: string;
  title: string;
  prompt?: string;
  depends_on: string[];
  declared_depends_on?: string[];
  requires_approval: boolean;
  validation_error: string | null;
}

export interface ChatActivity {
  id: string;
  run_id: string;
  kind: 'tool' | 'dispatch' | 'model' | 'approval';
  name: string;
  title: string;
  status: ChatActivityStatus;
  actor: string;
  agent_id?: string;
  task_id?: string;
  depends_on?: string[];
  thinking?: string;
  approval_id?: string;
  detail?: string;
  input?: string;
  output?: string;
  duration_ms?: number;
  created_at: string;
}

export interface Msg {
  id?: string;
  from: 'ceo' | 'boss' | 'agent' | 'system';
  text: string;
  time: string;
  senderName?: string;
  card?: MsgCard;
  thinking?: string;
  thinkingDone?: boolean;
  streaming?: boolean;
  activity?: ChatActivity;
  approval?: ChatApproval;
  runId?: string;
}

export interface Activity {
  id: string;
  title: string;
  position: string;
  steps: string[];
  current: number;
  detail: string;
  status: 'running' | 'done' | 'blocked' | 'failed';
}

export interface ChatWorkflowItem {
  id: string;
  agentId?: string;
  name: string;
  taskTitle: string;
  content: string;
  thinking: string;
  status: ChatActivityStatus;
  durationMs?: number;
  startedAt: number;
}

export interface ChatWorkflowRun {
  id: string;
  goal: string;
  plan: string;
  strategy?: string;
  source?: string;
  createdAt: number;
  items: ChatWorkflowItem[];
  activities: ChatActivity[];
  dag?: ChatDagNode[];
}

export interface ChatWorkflow {
  runs: ChatWorkflowRun[];
}

export const EMPTY_CHAT_WORKFLOW: ChatWorkflow = { runs: [] };

export type DlType = '简报' | '方案' | '脚本' | '素材';

export interface Deliverable {
  id: string;
  title: string;
  type: DlType;
  client: string;
  time: string;
  status: '已交付' | '待审核' | '失败' | '已取消';
  mark: string;
  color: string;
  sourceId?: string;
  rawStatus?: string;
  content?: string;
  contentLoaded?: boolean;
  contentMode?: 'live' | 'simulated' | 'mixed' | 'error';
}

export interface ErrItem {
  id: string;
  title: string;
  cause: string;
  impact: string;
  action: string;
  time: string;
  resolved: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  schedule: string;
  next: string;
  runs: number;
  position: string;
  enabled: boolean;
  once: boolean;
  mark: string;
  cronExpression?: string | null;
  startAt?: string | null;
  agentId?: string | null;
  durationMin?: number;
  completed?: boolean;
}

export interface KbItem {
  id: string;
  title: string;
  description?: string;
  desc: string;
  tags: string[];
  mark: string;
  color: string;
  sources?: Array<{
    source_id: string;
    filename: string;
    extension?: string;
    size_bytes?: number;
    ingest_status?: string;
    chunk_count?: number;
    error_message?: string;
  }>;
}

export interface Department {
  id: string;
  name: string;
  charter?: string;
}

export interface Position {
  id: string;
  name: string;
  deptId: string | null;
  managerId: string | null;
  avatar: string;
  enabled: boolean;
  soul: string;
  root?: boolean;
  /** 后端没有独立岗位表；这些字段把派生岗位映射回员工 Agent 及其岗位角色。 */
  sourceEmployeeId?: string;
  sourceRole?: string;
}

export interface Staff {
  id: string;
  name: string;
  positionId: string;
  managerId: string | null;
  avatar: string;
}

export interface OrgState {
  departments: Department[];
  positions: Position[];
  staff: Staff[];
}

export interface ModelOption {
  id: string;
  label: string;
  vendor: string;
  tier: string;
}

export interface DashboardKpi {
  label: string;
  value: string;
  trend: string;
  dir: 'up' | 'down';
}

export interface DashboardSeriesPoint {
  day: number;
  label: string;
  value: number;
}

export interface DashboardBreakdownItem {
  key: string;
  calls: number;
  tokens: number;
  cost: number;
}

export interface DashboardState {
  kpis: DashboardKpi[];
  series: DashboardSeriesPoint[];
  breakdown: DashboardBreakdownItem[];
  alerts: string[];
  failedTop: Array<{ goal: string; n: number }>;
  pnl: { margin: number; avgProjectCost: number } | null;
  insight: string;
  loaded: boolean;
}

export const EMPTY_DASHBOARD: DashboardState = {
  kpis: [
    { label: '网关近 30 天模型调用', value: '—', trend: '等待数据', dir: 'up' },
    { label: '网关近 30 天运行成功率', value: '—', trend: '等待数据', dir: 'up' },
    { label: '公司累计交付项目', value: '—', trend: '等待数据', dir: 'up' },
    { label: '公司累计运营成本', value: '—', trend: '等待数据', dir: 'down' },
    { label: '公司项目利润率', value: '—', trend: '等待数据', dir: 'up' },
    { label: '公司项目平均成本', value: '—', trend: '等待数据', dir: 'down' },
  ],
  series: [],
  breakdown: [],
  alerts: [],
  failedTop: [],
  pnl: null,
  insight: '进入看板后加载真实经营数据。',
  loaded: false,
};

export type ModalState =
  | { kind: 'new-project' }
  | { kind: 'new-dept' }
  | { kind: 'rename-dept'; deptId: string }
  | { kind: 'delete-dept'; deptId: string }
  | { kind: 'new-position'; deptId?: string }
  | { kind: 'delete-position'; positionId: string }
  | { kind: 'new-staff'; positionId?: string }
  | { kind: 'delete-staff'; staffId: string }
  | { kind: 'new-task' }
  | { kind: 'delete-task'; taskId: string }
  | { kind: 'delete-conversation'; conversationId: string }
  | { kind: 'decide-approval'; approvalId: string; decision: 'approved' | 'rejected' }
  | { kind: 'delete-deliverable'; deliverableId: string }
  | { kind: 'preview-deliverable'; deliverableId: string };

export interface Toast {
  id: string;
  msg: string;
}
