import { useWorkbench } from '../store';

export default function ConversationSidebar() {
  const { conversations, activeConversationId, selectConversation, newConversation, typing, deliverables } = useWorkbench();
  return (
    <aside className="conversation-sidebar">
      <div className="conversation-head">
        <div className="name">对话与项目</div>
        <button type="button" className="btn btn-primary btn-sm" onClick={newConversation} disabled={typing}>新开对话</button>
      </div>
      <div className="conversation-list">
        {conversations.map(item => {
          const project = item.projectId ? deliverables.find(d => d.sourceId === item.projectId) : undefined;
          return (
            <button type="button" key={item.id} className={item.id === activeConversationId ? 'conversation-item active' : 'conversation-item'} onClick={() => selectConversation(item.id)} disabled={typing}>
              <span className="conversation-title">{item.title}</span>
              <span className="conversation-meta">{item.projectId ? project?.status ?? '项目已创建' : '新对话草稿'}</span>
            </button>
          );
        })}
      </div>
    </aside>
  );
}
