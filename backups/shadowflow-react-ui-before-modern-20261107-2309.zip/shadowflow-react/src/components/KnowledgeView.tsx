import { useEffect, useRef, useState, type DragEvent, type KeyboardEvent } from 'react';
import { KB_TYPES } from '../data';
import { useWorkbench } from '../store';
import type { KnowledgeHitDto } from '../api';

const ACCEPT = '.txt,.md,.markdown,.log,.csv,.json,.jsonl,.html,.htm,.xlsx,.xlsm,.docx,.pdf,.png,.jpg,.jpeg,.webp,.bmp,.tif,.tiff';
const MAX_FILE_BYTES = 64 * 1024 * 1024;

function fileSize(bytes = 0): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export default function KnowledgeView() {
  const { knowledge, uploadKnowledge, searchKnowledge, kbFilter, setKbFilter, toast } = useWorkbench();
  const inputRef = useRef<HTMLInputElement>(null);
  const [targetId, setTargetId] = useState('');
  const [expandedId, setExpandedId] = useState('');
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState('');
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [hits, setHits] = useState<KnowledgeHitDto[]>([]);
  const list = knowledge.filter(k => kbFilter === '全部' || k.tags.includes(kbFilter));

  useEffect(() => {
    if (!knowledge.some(item => item.id === targetId)) setTargetId(knowledge[0]?.id ?? '');
  }, [knowledge, targetId]);

  const upload = async (files: File[]) => {
    if (!files.length || uploading) return;
    setError('');
    setHits([]);
    const oversized = files.find(file => file.size > MAX_FILE_BYTES);
    if (oversized) {
      setError(`${oversized.name} 超过 64 MB，请压缩或拆分后上传`);
      return;
    }
    setUploading(`正在上传并解析 ${files.length} 份资料…`);
    try {
      await uploadKnowledge(files, targetId || undefined);
      toast(`已上传并索引 ${files.length} 份资料，对话会自动检索引用`);
      if (inputRef.current) inputRef.current.value = '';
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setUploading('');
    }
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    void upload(Array.from(event.dataTransfer.files));
  };

  const onZoneKey = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      if (!uploading) inputRef.current?.click();
    }
  };

  const search = async () => {
    const packId = expandedId || targetId;
    if (!packId || !query.trim() || searching) return;
    setSearching(true);
    setError('');
    try {
      setHits(await searchKnowledge(packId, query.trim()));
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause));
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="view-inner knowledge-page">
      <div className="view-head">
        <h2>知识库</h2>
      </div>

      <div
        className={`kb-dropzone${dragging ? ' dragging' : ''}${uploading ? ' uploading' : ''}`}
        role="button"
        tabIndex={uploading ? -1 : 0}
        aria-label="上传知识库资料"
        onClick={() => { if (!uploading) inputRef.current?.click(); }}
        onKeyDown={onZoneKey}
        onDragEnter={event => { event.preventDefault(); setDragging(true); }}
        onDragOver={event => event.preventDefault()}
        onDragLeave={event => { if (!event.currentTarget.contains(event.relatedTarget as Node)) setDragging(false); }}
        onDrop={onDrop}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ACCEPT}
          hidden
          onChange={event => void upload(Array.from(event.target.files ?? []))}
        />
        <span className="kb-upload-mark" aria-hidden="true">↑</span>
        <div className="kb-upload-copy">
          <strong>{uploading || '拖动文件到这里，或点击选择'}</strong>
          <span>支持文档、表格、PDF 和图片，单文件不超过 64 MB</span>
        </div>
        {knowledge.length > 0 && (
          <select
            className="kb-target"
            aria-label="上传到知识库"
            value={targetId}
            disabled={Boolean(uploading)}
            onClick={event => event.stopPropagation()}
            onChange={event => setTargetId(event.target.value)}
          >
            {knowledge.map(item => <option key={item.id} value={item.id}>{item.title}</option>)}
          </select>
        )}
      </div>
      {error && <div className="kb-error" role="alert">{error}</div>}

      <div className="filter-tabs">
        {KB_TYPES.map(t => (
          <button key={t} className={'ftab' + (kbFilter === t ? ' active' : '')} onClick={() => setKbFilter(t)}>{t}</button>
        ))}
      </div>

      <div className="panel kb-list">
        {list.length ? list.map(k => (
          <div className={`kb-pack${expandedId === k.id ? ' expanded' : ''}`} key={k.id}>
            <button className="kb-item" onClick={() => { setExpandedId(expandedId === k.id ? '' : k.id); setHits([]); }}>
              <span className="kb-ico" style={{ background: k.color, color: 'var(--navy)' }}>{k.mark}</span>
              <span className="kb-pack-main">
                <span className="kb-title">{k.title}</span>
                <span className="kb-desc">{k.desc}</span>
                <span className="kb-tags">{k.tags.map(t => <span className="tag" key={t}>{t}</span>)}</span>
              </span>
              <span className="kb-expand" aria-hidden="true">{expandedId === k.id ? '−' : '+'}</span>
            </button>
            {expandedId === k.id && (
              <div className="kb-detail">
                <div className="kb-sources">
                  {(k.sources ?? []).length ? (k.sources ?? []).map(source => (
                    <div className="kb-source" key={source.source_id}>
                      <span className="kb-source-name">{source.filename}</span>
                      <span>{source.chunk_count ?? 0} 片段 · {fileSize(source.size_bytes)}</span>
                      <span className={source.ingest_status === 'done' ? 'kb-source-ok' : 'kb-source-failed'}>
                        {source.ingest_status === 'done' ? '可检索' : (source.error_message || source.ingest_status || '处理中')}
                      </span>
                    </div>
                  )) : <div className="empty-tip">还没有资料，从上方上传第一份文件</div>}
                </div>
                <form className="kb-search" onSubmit={event => { event.preventDefault(); void search(); }}>
                  <input value={query} onChange={event => setQuery(event.target.value)} placeholder="输入问题，验证这份资料能否被检索" aria-label="知识库检索问题" />
                  <button className="btn btn-secondary btn-sm" type="submit" disabled={searching || !query.trim()}>{searching ? '检索中…' : '测试检索'}</button>
                </form>
                {hits.length > 0 && <div className="kb-hits">{hits.map((hit, index) => (
                  <div className="kb-hit" key={`${index}-${hit.source ?? ''}`}>
                    <div className="kb-hit-source">来源：{hit.source_name || hit.source || k.title}</div>
                    <p>{hit.text}</p>
                  </div>
                ))}</div>}
                {!searching && hits.length === 0 && query && <div className="kb-search-hint">提交问题后，这里会显示实际命中的原文片段。</div>}
              </div>
            )}
          </div>
        )) : <div className="empty-tip">上传文件后会自动创建公司知识库</div>}
      </div>
    </div>
  );
}
