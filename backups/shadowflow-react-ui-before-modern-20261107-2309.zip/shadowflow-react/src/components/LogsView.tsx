import { useCallback, useEffect, useState } from 'react';
import { getOpcChatLogs, type OpcChatLogItemDto } from '../api';
import { useWorkbench } from '../store';
import ChatRichContent from './ChatRichContent';

function timeText(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { hour12: false });
}

export default function LogsView() {
  const { gwStatus, currentCompany } = useWorkbench();
  const [items, setItems] = useState<OpcChatLogItemDto[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async (cursor = '', append = false) => {
    if (gwStatus !== 'ok') return;
    setLoading(true);
    setError('');
    try {
      const result = await getOpcChatLogs(20, cursor);
      setItems(previous => append ? [...previous, ...result.items] : result.items);
      setNextCursor(result.next_cursor);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
    } finally {
      setLoading(false);
    }
  }, [gwStatus]);

  useEffect(() => { void load(); }, [load, currentCompany?.id]);

  return (
    <div className="view-inner logs-view">
      <div className="view-head"><h2>运行日志</h2><button className="btn btn-ghost btn-sm" disabled={loading || gwStatus !== 'ok'} onClick={() => void load()}>{loading ? '正在读取…' : '刷新日志'}</button></div>
      {error && <div className="panel panel-pad log-error" role="alert">{error}<button className="btn btn-ghost btn-sm" onClick={() => void load()}>重试</button></div>}
      {!items.length && !loading && !error && <div className="panel panel-pad empty-tip">当前公司还没有对话与执行日志</div>}
      {items.map(item => (
        <section className="log-conversation" key={item.conversation.id}>
          <header><div><h3>{item.conversation.title}</h3><span>{item.conversation.kind === 'group' ? '群聊' : '单聊'} · {timeText(item.conversation.updated_at)}</span></div></header>
          {item.runs.map(run => {
            const goal = run.messages.find(message => message.sender_kind === 'user')?.content ?? '历史执行';
            return (
              <details className="log-run" key={run.run_id} open={items.length === 1}>
                <summary><span>{goal}</span><small>{run.activities.length} 条活动 · {run.approvals.length} 次审批</small></summary>
                <div className="log-timeline">
                  {run.messages.map(message => (
                    <article className={`log-entry ${message.sender_kind}`} key={message.id}>
                      <div className="log-entry-meta"><strong>{message.sender_name}</strong><span>{message.task_title || message.channel}</span><time>{timeText(message.created_at)}</time></div>
                      {message.content && <ChatRichContent content={message.content} />}
                      {message.thinking && <details className="log-thinking"><summary>思考过程</summary><div>{message.thinking}</div></details>}
                    </article>
                  ))}
                  {run.approvals.map(approval => <div className="log-approval" key={approval.id}><strong>人工选择：{approval.decision === 'approve' ? '批准' : approval.decision === 'reject' ? '驳回' : '自定义'}</strong><span>{approval.custom_text || approval.outcome || '等待选择'}</span></div>)}
                </div>
              </details>
            );
          })}
          {item.unassigned_messages.map(message => <article className="log-entry standalone" key={message.id}><div className="log-entry-meta"><strong>{message.sender_name}</strong><time>{timeText(message.created_at)}</time></div><ChatRichContent content={message.content} /></article>)}
        </section>
      ))}
      {nextCursor && <button className="btn btn-ghost log-more" disabled={loading} onClick={() => void load(nextCursor, true)}>加载更早记录</button>}
    </div>
  );
}
